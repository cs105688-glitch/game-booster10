//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CzLwOo_2.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/ajustes",
			"/ferramentas",
			"/jogos",
			"/sessao/$gameId"
		],
		preloads: ["/assets/index-DuwW5bxN.js", "/assets/boost-Bl4e5ccA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DuwW5bxN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BkgObqoz.js",
			"/assets/shell-BSMWjY3h.js",
			"/assets/cn-CuXucDZS.js",
			"/assets/button-BBNiCRpo.js",
			"/assets/run-boost-flow-CNPJPCUT.js"
		]
	},
	"/ajustes": {
		filePath: "/workspace/src/routes/ajustes.tsx",
		children: void 0,
		preloads: [
			"/assets/ajustes-C65qQpBE.js",
			"/assets/shell-BSMWjY3h.js",
			"/assets/cn-CuXucDZS.js",
			"/assets/dist-C6gocahI.js",
			"/assets/switch-DnNyJx7H.js"
		]
	},
	"/ferramentas": {
		filePath: "/workspace/src/routes/ferramentas.tsx",
		children: void 0,
		preloads: [
			"/assets/ferramentas-BsU0Ep61.js",
			"/assets/shell-BSMWjY3h.js",
			"/assets/sun-DgsD1SNI.js",
			"/assets/cn-CuXucDZS.js",
			"/assets/switch-DnNyJx7H.js",
			"/assets/button-BBNiCRpo.js"
		]
	},
	"/jogos": {
		filePath: "/workspace/src/routes/jogos.tsx",
		children: void 0,
		preloads: [
			"/assets/jogos-wKTUH2bN.js",
			"/assets/shell-BSMWjY3h.js",
			"/assets/cn-CuXucDZS.js",
			"/assets/dist-C6gocahI.js",
			"/assets/button-BBNiCRpo.js",
			"/assets/run-boost-flow-CNPJPCUT.js"
		]
	},
	"/sessao/$gameId": {
		filePath: "/workspace/src/routes/sessao.$gameId.tsx",
		children: void 0,
		preloads: [
			"/assets/sessao._gameId-DHS24QxO.js",
			"/assets/sun-DgsD1SNI.js",
			"/assets/cn-CuXucDZS.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
