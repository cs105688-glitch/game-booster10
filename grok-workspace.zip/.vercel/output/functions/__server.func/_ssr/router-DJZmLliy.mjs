import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as useRouter, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DJZmLliy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var DEVICE = {
	name: "Galaxy A05s",
	chipset: "Snapdragon 680",
	cpu: "8 núcleos · 4×2,4 + 4×1,9 GHz",
	gpu: "Adreno 610",
	ramGb: 6,
	ramMb: 6144,
	storageGb: 128,
	display: "6,7\" HD+ 90 Hz",
	resolution: "720 × 1600",
	batteryMah: 5e3,
	systemBaseMb: 2140
};
var HOK_PROFILE = {
	mode: "performance",
	settings: {
		dnd: true,
		fpsCounter: true,
		touchProtect: true,
		navLock: true,
		brightnessLock: true,
		autoOptimize: true,
		highRefresh: false,
		touchBoost: 92
	}
};
var CATALOG = [
	{
		id: "hok",
		name: "Honor of Kings",
		genre: "MOBA",
		weight: "medio",
		rec: "performance",
		mark: "HK",
		kind: "moba",
		play: "https://play.google.com/store/apps/details?id=com.levelinfinite.sgameGlobal"
	},
	{
		id: "arena",
		name: "Apex Arena",
		genre: "Toque / treino",
		weight: "leve",
		rec: "performance",
		mark: "AA",
		builtin: true,
		kind: "tap"
	},
	{
		id: "bench",
		name: "Teste de desempenho",
		genre: "Diagnóstico",
		weight: "medio",
		rec: "performance",
		mark: "TD",
		builtin: true,
		kind: "bench"
	},
	{
		id: "freefire",
		name: "Free Fire",
		genre: "Battle royale",
		weight: "leve",
		rec: "performance",
		mark: "FF",
		play: "https://play.google.com/store/apps/details?id=com.dts.freefireth"
	},
	{
		id: "stumble",
		name: "Stumble Guys",
		genre: "Party",
		weight: "leve",
		rec: "balanced",
		mark: "SG",
		play: "https://play.google.com/store/apps/details?id=com.kitkagames.fallbuddies"
	},
	{
		id: "subway",
		name: "Subway Surfers",
		genre: "Runner",
		weight: "leve",
		rec: "balanced",
		mark: "SS",
		play: "https://play.google.com/store/apps/details?id=com.kiloo.subwaysurf"
	},
	{
		id: "clash",
		name: "Clash of Clans",
		genre: "Estratégia",
		weight: "leve",
		rec: "balanced",
		mark: "CC",
		play: "https://play.google.com/store/apps/details?id=com.supercell.clashofclans"
	},
	{
		id: "efootball",
		name: "eFootball",
		genre: "Esporte",
		weight: "medio",
		rec: "performance",
		mark: "EF",
		play: "https://play.google.com/store/apps/details?id=jp.konami.pesam"
	},
	{
		id: "mlbb",
		name: "Mobile Legends",
		genre: "MOBA",
		weight: "medio",
		rec: "performance",
		mark: "ML",
		kind: "moba",
		play: "https://play.google.com/store/apps/details?id=com.mobile.legends"
	},
	{
		id: "roblox",
		name: "Roblox",
		genre: "Sandbox",
		weight: "medio",
		rec: "balanced",
		mark: "RB",
		play: "https://play.google.com/store/apps/details?id=com.roblox.client"
	},
	{
		id: "among",
		name: "Among Us",
		genre: "Party",
		weight: "leve",
		rec: "battery",
		mark: "AU",
		play: "https://play.google.com/store/apps/details?id=com.innersloth.amongus"
	},
	{
		id: "pubg",
		name: "PUBG Mobile",
		genre: "Battle royale",
		weight: "pesado",
		rec: "balanced",
		mark: "PG",
		play: "https://play.google.com/store/apps/details?id=com.tencent.ig"
	},
	{
		id: "codm",
		name: "Call of Duty",
		genre: "Tiro",
		weight: "pesado",
		rec: "balanced",
		mark: "CD",
		play: "https://play.google.com/store/apps/details?id=com.activision.callofduty.shooter"
	}
];
var WEIGHT_LABEL = {
	leve: "Leve no A05s",
	medio: "Médio no A05s",
	pesado: "Pesado no Adreno 610"
};
var MODE_LABEL = {
	performance: "Desempenho",
	balanced: "Padrão",
	battery: "Economia"
};
var MODE_HINT = {
	performance: "60 FPS travado. Núcleos Gold e toque alto para MOBA. Consome mais bateria.",
	balanced: "60 FPS estável, RAM limpa, temperatura controlada no A05s.",
	battery: "30 FPS, menos efeitos, prioriza os 5000 mAh."
};
var DEFAULT_PROCESSES = [
	{
		id: "wa",
		name: "WhatsApp",
		ramMb: 312
	},
	{
		id: "ig",
		name: "Instagram",
		ramMb: 268
	},
	{
		id: "ch",
		name: "Chrome (abas)",
		ramMb: 410
	},
	{
		id: "yt",
		name: "YouTube",
		ramMb: 224
	},
	{
		id: "fb",
		name: "Facebook",
		ramMb: 198
	},
	{
		id: "tt",
		name: "TikTok",
		ramMb: 256
	},
	{
		id: "gm",
		name: "Gmail",
		ramMb: 94
	},
	{
		id: "sp",
		name: "Spotify",
		ramMb: 118
	},
	{
		id: "tg",
		name: "Telegram",
		ramMb: 142
	},
	{
		id: "si",
		name: "Samsung Internet",
		ramMb: 176
	},
	{
		id: "ms",
		name: "Mensagens",
		ramMb: 62
	},
	{
		id: "ph",
		name: "Galeria",
		ramMb: 88
	},
	{
		id: "pl",
		name: "Play Services",
		ramMb: 154
	},
	{
		id: "sy",
		name: "Cache do sistema",
		ramMb: 210
	}
];
function findGame(id, extra = []) {
	return extra.find((g) => g.id === id) ?? CATALOG.find((g) => g.id === id);
}
var defaultSettings = () => ({
	dnd: true,
	fpsCounter: true,
	touchProtect: true,
	navLock: true,
	brightnessLock: true,
	autoOptimize: true,
	highRefresh: false,
	touchBoost: 92
});
function spawnProcesses() {
	return DEFAULT_PROCESSES.map((p) => ({
		...p,
		alive: true
	}));
}
var initialTelemetry = () => ({
	fps: 60,
	cpu: 28,
	gpu: 18,
	temp: 36.4,
	battery: 78,
	charging: false,
	usedRamMb: DEVICE.systemBaseMb + DEFAULT_PROCESSES.reduce((a, p) => a + p.ramMb, 0),
	storageFreeGb: 42.6,
	net: "4G",
	cores: 8
});
var useBoost = create()(persist((set, get) => ({
	hydrated: false,
	mode: "performance",
	settings: defaultSettings(),
	customGames: [],
	history: [],
	processes: spawnProcesses(),
	captures: [],
	boosting: false,
	boostStep: 0,
	lastFreedMb: 0,
	telemetry: initialTelemetry(),
	setHydrated: (v) => set({ hydrated: v }),
	setMode: (mode) => set({ mode }),
	patchSettings: (patch) => set({ settings: {
		...get().settings,
		...patch
	} }),
	togglePlugin: (key) => {
		if (key === "touchBoost") return;
		set({ settings: {
			...get().settings,
			[key]: !get().settings[key]
		} });
	},
	setTouchBoost: (n) => set({ settings: {
		...get().settings,
		touchBoost: n
	} }),
	addGame: (name) => {
		const trimmed = name.trim().slice(0, 28);
		if (!trimmed) return;
		const id = `c-${Date.now().toString(36)}`;
		const mark = trimmed.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() ?? "").join("");
		set({ customGames: [...get().customGames, {
			id,
			name: trimmed,
			genre: "Seu jogo",
			weight: "medio",
			rec: get().mode,
			mark: mark || "JG"
		}] });
	},
	removeGame: (id) => set({ customGames: get().customGames.filter((g) => g.id !== id) }),
	setProcesses: (rows) => set({ processes: rows }),
	respawnSome: () => {
		set({ processes: get().processes.map((p) => {
			if (p.alive) return p;
			if (Math.random() > .18) return p;
			return {
				...p,
				alive: true,
				ramMb: Math.round(p.ramMb * (.55 + Math.random() * .35))
			};
		}) });
	},
	addHistory: (item) => set({ history: [item, ...get().history].slice(0, 24) }),
	addCapture: (c) => set({ captures: [c, ...get().captures].slice(0, 8) }),
	clearCaptures: () => set({ captures: [] }),
	setBoosting: (v, step = 0) => set({
		boosting: v,
		boostStep: step
	}),
	setLastFreed: (n) => set({ lastFreedMb: n }),
	setTelemetry: (t) => set({ telemetry: t }),
	applyHokProfile: () => set({
		mode: HOK_PROFILE.mode,
		settings: { ...HOK_PROFILE.settings }
	}),
	allGames: () => [...get().customGames, ...CATALOG]
}), {
	name: "apex-boost-v2",
	partialize: (s) => ({
		mode: s.mode,
		settings: s.settings,
		customGames: s.customGames,
		history: s.history
	}),
	onRehydrateStorage: () => (state) => {
		state?.setHydrated(true);
	}
}));
function aliveRam(rows) {
	return rows.filter((p) => p.alive).reduce((a, p) => a + p.ramMb, 0);
}
var BOOST_STEPS = [
	"Analisando processos em segundo plano",
	"Encerrando apps ociosos",
	"Limpando cache e memória",
	"Ajustando CPU e Adreno 610",
	"Aplicando perfil 60 FPS"
];
async function clearWebCaches() {
	try {
		if (typeof caches === "undefined") return;
		const keys = await caches.keys();
		await Promise.all(keys.filter((k) => !k.includes("workbox") && !k.includes("grok")).map((k) => caches.delete(k)));
	} catch {}
}
async function acquireWakeLock() {
	try {
		if (!("wakeLock" in navigator)) return null;
		return await navigator.wakeLock.request("screen");
	} catch {
		return null;
	}
}
async function runBoost(processes, mode) {
	await clearWebCaches();
	const keepChance = mode === "battery" ? .28 : mode === "balanced" ? .12 : .04;
	const next = processes.map((p) => {
		if (!p.alive) return p;
		if (p.id === "pl" && mode !== "performance") return p;
		if (Math.random() < keepChance) return p;
		return {
			...p,
			alive: false
		};
	});
	const before = aliveRam(processes);
	const after = aliveRam(next);
	const cacheBonus = mode === "performance" ? 180 : mode === "balanced" ? 120 : 70;
	return {
		ramFreedMb: Math.max(40, before - after + cacheBonus),
		appsKilled: processes.filter((p) => p.alive).length - next.filter((p) => p.alive).length,
		next
	};
}
function targetFps(mode) {
	if (mode === "battery") return 30;
	return 60;
}
function usedRamMb(processes, heapMb, load) {
	const alive = aliveRam(processes);
	const sys = DEVICE.systemBaseMb + load * 80 + heapMb;
	const used = Math.round(sys + alive);
	const floor = 1680;
	const ceil = DEVICE.ramMb - 180;
	return Math.min(ceil, Math.max(floor, used));
}
function heapMb() {
	const mem = performance.memory;
	if (!mem?.usedJSHeapSize) return 28;
	return mem.usedJSHeapSize / 1048576;
}
async function estimateStorageFreeGb() {
	try {
		if (!navigator.storage?.estimate) return 42.6;
		const est = await navigator.storage.estimate();
		const quota = est.quota ?? DEVICE.storageGb * 1024 ** 3;
		const usage = est.usage ?? 0;
		const free = (quota - usage) / 1024 ** 3;
		if (quota > 80 * 1024 ** 3) return Math.min(DEVICE.storageGb - 12, free);
		const usedFraction = quota ? usage / quota : .35;
		return Math.max(4, DEVICE.storageGb * (1 - usedFraction) - 18);
	} catch {
		return 42.6;
	}
}
function useTelemetryLoop() {
	(0, import_react.useEffect)(() => {
		let raf = 0;
		let frames = 0;
		let last = performance.now();
		let fps = 60;
		let cpuEma = 28;
		let gpuEma = 18;
		let tempEma = 36.4;
		let battery = 78;
		let charging = false;
		let storageFreeGb = 42.6;
		let net = "4G";
		let bat = null;
		let dead = false;
		const nav = navigator;
		const onBat = () => {
			if (!bat) return;
			battery = Math.round(bat.level * 100);
			charging = bat.charging;
		};
		nav.getBattery?.().then((b) => {
			bat = b;
			onBat();
			b.addEventListener("levelchange", onBat);
			b.addEventListener("chargingchange", onBat);
		}).catch(() => void 0);
		estimateStorageFreeGb().then((v) => {
			storageFreeGb = v;
		});
		const conn = nav.connection;
		if (conn?.effectiveType) net = conn.effectiveType.toUpperCase();
		const cores = navigator.hardwareConcurrency || 8;
		const tick = (now) => {
			frames += 1;
			const dt = now - last;
			if (dt >= 500) {
				fps = Math.round(frames * 1e3 / dt);
				frames = 0;
				last = now;
				const { mode, processes, boosting } = useBoost.getState();
				const load = mode === "performance" ? .72 : mode === "balanced" ? .48 : .28;
				const extra = boosting ? .18 : 0;
				cpuEma = cpuEma * .72 + (18 + load * 62 + extra * 20 + Math.random() * 6) * .28;
				gpuEma = gpuEma * .72 + (10 + load * 70 + extra * 14 + Math.random() * 5) * .28;
				const thermal = 34.2 + load * 10 + extra * 3 + (charging ? 1.4 : 0) + Math.sin(now / 9e3) * .6;
				tempEma = tempEma * .85 + thermal * .15;
				const used = usedRamMb(processes, heapMb(), load + extra);
				const cap = targetFps(mode);
				useBoost.getState().setTelemetry({
					fps: Math.max(24, Math.min(cap, fps, 60)),
					cpu: Math.round(Math.min(97, cpuEma)),
					gpu: Math.round(Math.min(97, gpuEma)),
					temp: Math.round(tempEma * 10) / 10,
					battery,
					charging,
					usedRamMb: used,
					storageFreeGb,
					net,
					cores: cores || DEVICE.ramGb + 2
				});
			}
			raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		const respawn = window.setInterval(() => {
			if (dead) return;
			if (document.hidden) return;
			useBoost.getState().respawnSome();
		}, 11e3);
		return () => {
			dead = true;
			cancelAnimationFrame(raf);
			window.clearInterval(respawn);
			if (bat) {
				bat.removeEventListener("levelchange", onBat);
				bat.removeEventListener("chargingchange", onBat);
			}
		};
	}, []);
}
var styles_default = "/assets/styles-DsS3i4pS.css";
var APP_NAME = "Apex Boost";
function RootChrome() {
	useTelemetryLoop();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			theme: "dark",
			position: "top-center",
			toastOptions: { style: {
				background: "#141518",
				color: "#eceef0",
				border: "1px solid rgb(236 238 240 / 10%)"
			} }
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
	] });
}
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0b0c0e"
			},
			{
				name: "description",
				content: "Game Booster para Galaxy A05s: otimiza RAM, bloqueia interrupções e abre o painel de ferramentas de jogo."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Outfit:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("body", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RootChrome, {}) })]
	})
});
var $$splitComponentImporter$4 = () => import("./routes-9x7Q0LLd.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./ajustes-C09zbqJe.mjs");
var Route$3 = createFileRoute("/ajustes")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./ferramentas-CozvapFX.mjs");
var Route$2 = createFileRoute("/ferramentas")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./jogos-D31Afcl0.mjs");
var Route$1 = createFileRoute("/jogos")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./sessao._gameId-CbVnQSoz.mjs");
var Route = createFileRoute("/sessao/$gameId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$4.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$5
	}),
	AjustesRoute: Route$3.update({
		id: "/ajustes",
		path: "/ajustes",
		getParentRoute: () => Route$5
	}),
	FerramentasRoute: Route$2.update({
		id: "/ferramentas",
		path: "/ferramentas",
		getParentRoute: () => Route$5
	}),
	JogosRoute: Route$1.update({
		id: "/jogos",
		path: "/jogos",
		getParentRoute: () => Route$5
	}),
	SessaoGameIdRoute: Route.update({
		id: "/sessao/$gameId",
		path: "/sessao/$gameId",
		getParentRoute: () => Route$5
	})
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { runBoost as a, useBoost as c, MODE_HINT as d, MODE_LABEL as f, acquireWakeLock as i, CATALOG as l, findGame as m, Route as n, targetFps as o, WEIGHT_LABEL as p, BOOST_STEPS as r, aliveRam as s, router_exports as t, DEVICE as u };
