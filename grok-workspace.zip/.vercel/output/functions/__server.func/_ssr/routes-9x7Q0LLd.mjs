import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Wifi } from "../_libs/lucide-react.mjs";
import { c as useBoost, d as MODE_HINT, f as MODE_LABEL, s as aliveRam, u as DEVICE } from "./router-DJZmLliy.mjs";
import { t as cn } from "./cn-Ccejyh36.mjs";
import { i as formatMb, n as formatAgo, r as formatGb, t as Shell } from "./shell-BTVghbJR.mjs";
import { t as Button } from "./button-zcPWBoXR.mjs";
import { t as runBoostFlow } from "./run-boost-flow-_q0-Hmrm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-9x7Q0LLd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ORDER = [
	"performance",
	"balanced",
	"battery"
];
function ModePills({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-3 gap-2 rounded-xl bg-surface p-1.5 shadow-[var(--shadow-border)]",
		children: ORDER.map((m) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(m),
				className: cn("h-11 rounded-lg text-sm font-medium transition-[background-color,color,transform] duration-150", "active:scale-[0.96]", m === value ? "bg-fg text-accent-fg" : "text-muted hover:text-fg"),
				children: MODE_LABEL[m]
			}, m);
		})
	});
}
function RamGauge({ usedMb, pulse }) {
	const total = DEVICE.ramMb;
	const free = Math.max(0, total - usedMb);
	const pct = Math.min(1, usedMb / total);
	const r = 86;
	const c = 2 * Math.PI * r;
	const dash = c * pct;
	const tone = pct > .86 ? "text-danger" : pct > .72 ? "text-warn" : "text-accent";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto grid place-items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 200 200",
			className: cn("size-44 sm:size-56", pulse && "animate-pulse"),
			"aria-hidden": true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "100",
				cy: "100",
				r,
				fill: "none",
				stroke: "var(--color-raised)",
				strokeWidth: "12"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "100",
				cy: "100",
				r,
				fill: "none",
				className: cn("gauge-ring", tone),
				stroke: "currentColor",
				strokeWidth: "12",
				strokeLinecap: "round",
				strokeDasharray: `${dash} ${c - dash}`
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0 flex flex-col items-center justify-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.16em] text-subtle uppercase",
					children: "RAM livre"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tabular mt-1 font-mono text-3xl font-medium tracking-tight sm:text-4xl",
					children: formatMb(free)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tabular mt-1 text-sm text-muted",
					children: [
						"de ",
						DEVICE.ramGb,
						" GB"
					]
				})
			]
		})]
	});
}
function Home() {
	const navigate = useNavigate();
	const mode = useBoost((s) => s.mode);
	const setMode = useBoost((s) => s.setMode);
	const telemetry = useBoost((s) => s.telemetry);
	const processes = useBoost((s) => s.processes);
	const boosting = useBoost((s) => s.boosting);
	const history = useBoost((s) => s.history);
	const applyHok = useBoost((s) => s.applyHokProfile);
	const auto = useBoost((s) => s.settings.autoOptimize);
	const last = history[0];
	const background = processes.filter((p) => p.alive).length;
	const backgroundRam = aliveRam(processes);
	const ramPct = Math.round(telemetry.usedRamMb / DEVICE.ramMb * 100);
	const tempTone = telemetry.temp >= 47 ? "text-danger" : telemetry.temp >= 41 ? "text-warn" : "text-ok";
	const [hokBusy, setHokBusy] = (0, import_react.useState)(false);
	const launchHok = async () => {
		setHokBusy(true);
		try {
			applyHok();
			if (auto) await runBoostFlow({
				gameName: "Honor of Kings",
				mode: "performance"
			});
			await navigate({
				to: "/sessao/$gameId",
				params: { gameId: "hok" }
			});
		} finally {
			setHokBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.18em] text-subtle uppercase",
					children: DEVICE.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-medium",
					children: "Apex Boost"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						DEVICE.chipset,
						" · ",
						DEVICE.gpu,
						" · ",
						DEVICE.ramGb,
						" GB"
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RamGauge, {
				usedMb: telemetry.usedRamMb,
				pulse: boosting
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 grid grid-cols-3 gap-2 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Em uso",
					value: `${ramPct}%`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Segundo plano",
					value: `${background}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Apps",
					value: formatMb(backgroundRam)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModePills, {
				value: mode,
				onChange: setMode
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: MODE_HINT[mode]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4 w-full",
			size: "lg",
			disabled: boosting,
			onClick: () => void runBoostFlow(),
			children: "Otimizar agora"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			disabled: boosting || hokBusy,
			onClick: () => void launchHok(),
			className: "mt-2 flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-border)] active:scale-[0.96]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-sm font-medium",
				children: "Honor of Kings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted",
				children: "Perfil MOBA · toque alto · DND"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-sm text-accent tabular",
				children: [60, " FPS"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-4 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					label: "CPU",
					value: `${telemetry.cpu}%`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					label: "GPU",
					value: `${telemetry.gpu}%`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					label: "Temp",
					value: `${telemetry.temp.toFixed(0)}°`,
					valueClass: tempTone
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					label: "Livre",
					value: formatGb(telemetry.storageFreeGb, 0)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex items-center justify-between rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "Rede do A05s"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-sm text-accent tabular",
				children: telemetry.net
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 rounded-xl bg-surface px-4 py-3 text-sm text-muted shadow-[var(--shadow-border)]",
			children: last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				"Última: ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-fg tabular",
					children: formatMb(last.ramFreedMb)
				}),
				" · ",
				last.appsKilled,
				" apps ·",
				" ",
				formatAgo(last.at)
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Toque em otimizar antes de um jogo pesado no Adreno 610." })
		})
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "tabular font-mono text-lg",
		children: value
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[0.7rem] tracking-wide text-subtle uppercase",
		children: label
	})] });
}
function Chip({ label, value, valueClass }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-2 py-3 text-center shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[0.65rem] tracking-wide text-subtle uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `tabular mt-1 font-mono text-sm ${valueClass ?? "text-fg"}`,
			children: value
		})]
	});
}
//#endregion
export { Home as component };
