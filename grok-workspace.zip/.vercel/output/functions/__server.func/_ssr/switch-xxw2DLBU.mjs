import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cn } from "./cn-Ccejyh36.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/switch-xxw2DLBU.js
var import_jsx_runtime = require_jsx_runtime();
function Switch({ checked, onCheckedChange, disabled, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		checked,
		onCheckedChange,
		disabled,
		"aria-label": label,
		className: cn("relative h-7 w-12 shrink-0 rounded-full transition-colors duration-150", "bg-raised shadow-[var(--shadow-border)]", "data-[state=checked]:bg-accent", "disabled:opacity-40"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("block size-5 translate-x-1 rounded-full bg-fg transition-transform duration-150", "data-[state=checked]:translate-x-6 data-[state=checked]:bg-accent-fg") })
	});
}
//#endregion
export { Switch as t };
