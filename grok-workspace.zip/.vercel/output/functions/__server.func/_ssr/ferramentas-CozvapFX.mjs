import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as Lock, m as Gauge, p as Hand, s as Sun, t as Zap, v as Camera, y as BellOff } from "../_libs/lucide-react.mjs";
import { c as useBoost } from "./router-DJZmLliy.mjs";
import { n as formatAgo, t as Shell } from "./shell-BTVghbJR.mjs";
import { t as Switch } from "./switch-xxw2DLBU.mjs";
import { t as Button } from "./button-zcPWBoXR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ferramentas-CozvapFX.js
var import_jsx_runtime = require_jsx_runtime();
var PLUGINS = [
	{
		key: "dnd",
		title: "Não perturbe",
		hint: "Silencia toasts e alertas do booster durante a partida.",
		icon: BellOff
	},
	{
		key: "fpsCounter",
		title: "Contador de FPS",
		hint: "Overlay no canto, como no Game Tools da Samsung.",
		icon: Gauge
	},
	{
		key: "touchProtect",
		title: "Proteção de borda",
		hint: "Ignora toques acidentais nas laterais do A05s.",
		icon: Hand
	},
	{
		key: "navLock",
		title: "Bloquear navegação",
		hint: "Evita gesto de voltar encerrar a sessão.",
		icon: Lock
	},
	{
		key: "brightnessLock",
		title: "Manter tela ligada",
		hint: "Wake Lock para não apagar no meio da jogada.",
		icon: Sun
	},
	{
		key: "autoOptimize",
		title: "Otimizar ao abrir",
		hint: "Limpa RAM antes de cada jogo da biblioteca.",
		icon: Zap
	}
];
function Ferramentas() {
	const settings = useBoost((s) => s.settings);
	const toggle = useBoost((s) => s.togglePlugin);
	const captures = useBoost((s) => s.captures);
	const clear = useBoost((s) => s.clearCaptures);
	const alive = useBoost((s) => s.processes).filter((p) => p.alive);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.18em] text-subtle uppercase",
					children: "Game Tools"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-medium",
					children: "Ferramentas"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Os mesmos atalhos do Game Tools: captura, gravação, DND e FPS. Honor of Kings usa 60 FPS travado no Adreno 610."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/sessao/$gameId",
			params: { gameId: "hok" },
			className: "mt-5 flex h-12 items-center justify-center rounded-xl bg-fg text-sm font-medium text-accent-fg",
			children: "Abrir perfil Honor of Kings"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 text-sm font-medium",
			children: "Plugins"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2",
			children: PLUGINS.map((p) => {
				const Icon = p.icon;
				const on = Boolean(settings[p.key]);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 place-items-center rounded-lg bg-raised text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: p.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: p.hint
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: on,
							onCheckedChange: () => toggle(p.key),
							label: p.title
						})
					]
				}, p.key);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 text-sm font-medium",
			children: "Álbum da partida"
		}),
		captures.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 rounded-xl bg-surface px-4 py-3 text-sm text-muted shadow-[var(--shadow-border)]",
			children: "Capturas e clips aparecem aqui depois que você usa Câmera ou Gravar no overlay."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: captures.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: c.dataUrl,
						alt: c.kind === "shot" ? "Captura de tela" : "Quadro da gravação",
						className: "aspect-video w-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
						className: "flex items-center justify-between px-3 py-2 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1",
							children: [c.kind === "shot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-3" }), c.kind === "shot" ? "Foto" : "Clip"]
						}), formatAgo(c.at)]
					})]
				}, c.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				className: "mt-2 w-full",
				onClick: clear,
				children: "Limpar álbum"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 text-sm font-medium",
			children: "Segundo plano agora"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-3 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]",
			children: [alive.slice(0, 8).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-muted tabular",
					children: [p.ramMb, " MB"]
				})]
			}, p.id)), alive.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "px-4 py-3 text-sm text-muted",
				children: "Nenhum app ocioso. Booster em efeito."
			}) : null]
		})
	] });
}
//#endregion
export { Ferramentas as component };
