import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as useBoost, f as MODE_LABEL, u as DEVICE } from "./router-DJZmLliy.mjs";
import { t as cn } from "./cn-Ccejyh36.mjs";
import { i as formatMb, t as Shell } from "./shell-BTVghbJR.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as Switch } from "./switch-xxw2DLBU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ajustes-C09zbqJe.js
var import_jsx_runtime = require_jsx_runtime();
function Slider({ value, onValueChange, min = 0, max = 100, step = 1, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		value: [value],
		min,
		max,
		step,
		onValueChange: (v) => onValueChange(v[0] ?? value),
		"aria-label": label,
		className: "relative flex h-11 w-full touch-none items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full rounded-full bg-raised",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full rounded-full bg-accent" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: cn("block size-5 rounded-full bg-fg shadow-[var(--shadow-border)]", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50") })]
	});
}
function Ajustes() {
	const settings = useBoost((s) => s.settings);
	const patch = useBoost((s) => s.patchSettings);
	const setTouch = useBoost((s) => s.setTouchBoost);
	const history = useBoost((s) => s.history);
	const telemetry = useBoost((s) => s.telemetry);
	const chart = [...history].slice(0, 12).reverse();
	const maxMb = Math.max(200, ...chart.map((h) => h.ramFreedMb));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.18em] text-subtle uppercase",
				children: "Perfil do aparelho"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-3xl font-medium",
				children: "Ajustes"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: DEVICE.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Chipset",
							v: DEVICE.chipset
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "GPU",
							v: DEVICE.gpu
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "CPU",
							v: "8 núcleos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "RAM",
							v: `${DEVICE.ramGb} GB`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Armazenamento",
							v: `${DEVICE.storageGb} GB`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Tela",
							v: DEVICE.display
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Resolução",
							v: DEVICE.resolution
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Alvo FPS",
							v: "60 travado"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Bateria",
							v: `${DEVICE.batteryMah} mAh`
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-xs text-muted",
					children: [
						"Núcleos visíveis neste aparelho: ",
						telemetry.cores,
						". O booster assume o A05s mesmo se o navegador reportar outra memória."
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-5 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Sensibilidade de toque"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Perfil MOBA: área de acerto maior para skills. Honor of Kings usa 92 por padrão."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						value: settings.touchBoost,
						onValueChange: setTouch,
						label: "Sensibilidade"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "tabular mt-1 text-right font-mono text-xs text-subtle",
					children: settings.touchBoost
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Manter tela ligada"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Impede o A05s de apagar no jogo"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: settings.brightnessLock,
						onCheckedChange: (v) => patch({ brightnessLock: v }),
						label: "Manter tela ligada"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-5 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Memória liberada"
				}),
				chart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Rode o booster para ver o histórico."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex h-24 items-end gap-1",
					children: chart.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 rounded-sm bg-accent/80",
						style: { height: `${Math.max(8, h.ramFreedMb / maxMb * 100)}%` },
						title: formatMb(h.ramFreedMb)
					}, `${h.at}-${i}`))
				}),
				history[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted",
					children: [
						"Último modo: ",
						MODE_LABEL[history[0].mode],
						" · ",
						formatMb(history[0].ramFreedMb)
					]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 pb-4 text-xs leading-relaxed text-subtle",
			children: "O Apex Boost replica o fluxo do Game Booster — launcher, modos, overlay, DND, captura e limpeza de memória — dentro do app. Relógios de CPU do Android continuam com a Samsung; aqui o A05s ganha o painel, o perfil de 6 GB / Adreno 610 e as ferramentas de partida."
		})
	] });
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs text-subtle",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-0.5",
		children: v
	})] });
}
//#endregion
export { Ajustes as component };
