import { a as runBoost, c as useBoost, r as BOOST_STEPS } from "./router-DJZmLliy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/run-boost-flow-_q0-Hmrm.js
function sleep(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
async function runBoostFlow(opts) {
	const store = useBoost.getState();
	if (store.boosting) return null;
	const mode = opts?.mode ?? store.mode;
	store.setBoosting(true, 0);
	try {
		if (typeof navigator.vibrate === "function") navigator.vibrate(12);
		for (let i = 0; i < BOOST_STEPS.length; i += 1) {
			store.setBoosting(true, i);
			await sleep(420);
		}
		const result = await runBoost(useBoost.getState().processes, mode);
		store.setProcesses(result.next);
		store.setLastFreed(result.ramFreedMb);
		store.addHistory({
			at: Date.now(),
			ramFreedMb: result.ramFreedMb,
			appsKilled: result.appsKilled,
			mode,
			gameName: opts?.gameName
		});
		store.setBoosting(true, BOOST_STEPS.length);
		await sleep(700);
		return result;
	} finally {
		useBoost.getState().setBoosting(false, 0);
	}
}
//#endregion
export { runBoostFlow as t };
