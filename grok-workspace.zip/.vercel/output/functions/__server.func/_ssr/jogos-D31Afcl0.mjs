import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as X, o as Trash2, u as Plus } from "../_libs/lucide-react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { c as useBoost, f as MODE_LABEL, l as CATALOG, p as WEIGHT_LABEL } from "./router-DJZmLliy.mjs";
import { t as cn } from "./cn-Ccejyh36.mjs";
import { t as Shell } from "./shell-BTVghbJR.mjs";
import { t as Button } from "./button-zcPWBoXR.mjs";
import { t as runBoostFlow } from "./run-boost-flow-_q0-Hmrm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jogos-D31Afcl0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Dialog({ open, onOpenChange, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-bg/70 data-[state=open]:animate-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: cn("fixed top-1/2 left-1/2 z-50 w-[min(100%-2rem,24rem)] -translate-x-1/2 -translate-y-1/2", "rounded-2xl bg-surface p-5 text-fg shadow-[var(--shadow-border)]", "focus:outline-none"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "text-lg font-medium tracking-tight",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "flex size-11 items-center justify-center rounded-lg text-muted hover:bg-raised hover:text-fg",
					"aria-label": "Fechar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), children]
		})] })
	});
}
function Jogos() {
	const navigate = useNavigate();
	const custom = useBoost((s) => s.customGames);
	const addGame = useBoost((s) => s.addGame);
	const removeGame = useBoost((s) => s.removeGame);
	const auto = useBoost((s) => s.settings.autoOptimize);
	const applyHok = useBoost((s) => s.applyHokProfile);
	const all = (0, import_react.useMemo)(() => [...custom, ...CATALOG], [custom]);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(null);
	const launch = async (game) => {
		setBusy(game.id);
		try {
			if (game.id === "hok" || game.kind === "moba") applyHok();
			if (auto) await runBoostFlow({
				gameName: game.name,
				mode: game.rec
			});
			await navigate({
				to: "/sessao/$gameId",
				params: { gameId: game.id }
			});
		} finally {
			setBusy(null);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between pt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.18em] text-subtle uppercase",
				children: "Game Launcher"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-3xl font-medium",
				children: "Jogos"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				size: "icon",
				onClick: () => setOpen(true),
				"aria-label": "Adicionar jogo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Perfis calibrados para Adreno 610. Honor of Kings entra em 60 FPS travado, toque alto e DND."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 space-y-2",
			children: all.map((game) => {
				const customRow = custom.some((g) => g.id === game.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-xl bg-surface p-2 pl-3 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-12 shrink-0 place-items-center rounded-lg bg-raised font-medium tracking-wide",
							children: game.mark
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-medium",
								children: game.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted",
								children: [
									game.genre,
									" · ",
									WEIGHT_LABEL[game.weight]
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("hidden rounded-full px-2 py-1 text-[0.65rem] tracking-wide uppercase sm:inline", "bg-raised text-muted"),
							children: MODE_LABEL[game.rec]
						}),
						customRow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center text-subtle hover:text-danger",
							onClick: () => removeGame(game.id),
							"aria-label": `Remover ${game.name}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							className: "mr-1",
							disabled: busy === game.id,
							onClick: () => void launch(game),
							children: "Jogar"
						})
					]
				}, game.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
			open,
			onOpenChange: setOpen,
			title: "Adicionar jogo",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-sm text-muted",
					htmlFor: "game-name",
					children: "Nome"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "game-name",
					value: name,
					onChange: (e) => setName(e.target.value),
					placeholder: "Ex.: Meu jogo",
					className: "mt-2 h-11 w-full rounded-lg bg-raised px-3 text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4 w-full",
					onClick: () => {
						addGame(name);
						setName("");
						setOpen(false);
					},
					children: "Salvar na biblioteca"
				})
			]
		})
	] });
}
//#endregion
export { Jogos as component };
