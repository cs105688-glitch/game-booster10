import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Check, c as Sparkles, h as Gamepad2, l as Settings2, m as Gauge } from "../_libs/lucide-react.mjs";
import { c as useBoost, r as BOOST_STEPS } from "./router-DJZmLliy.mjs";
import { t as cn } from "./cn-Ccejyh36.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-BTVghbJR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatMb(mb) {
	if (!Number.isFinite(mb) || mb < 0) return "0 MB";
	if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`;
	return `${Math.round(mb)} MB`;
}
function formatGb(gb, digits = 1) {
	if (!Number.isFinite(gb)) return "0 GB";
	return `${gb.toFixed(digits)} GB`;
}
function formatAgo(ts) {
	const delta = Date.now() - ts;
	const min = Math.round(delta / 6e4);
	if (min < 1) return "agora";
	if (min < 60) return `há ${min} min`;
	const h = Math.round(min / 60);
	if (h < 24) return `há ${h} h`;
	return `há ${Math.round(h / 24)} d`;
}
function formatClock(date) {
	return date.toLocaleTimeString("pt-BR", {
		hour: "2-digit",
		minute: "2-digit"
	});
}
function BoostOverlay({ step, done, freedMb, killed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-bg/80 p-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.18em] text-subtle uppercase",
					children: "Game Booster"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-xl font-medium",
					children: done ? "Aparelho otimizado" : "Otimizando o A05s"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 space-y-2",
					children: BOOST_STEPS.map((label, i) => {
						const state = done || i < step ? "done" : i === step ? "now" : "wait";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("grid size-7 place-items-center rounded-full", state === "done" && "bg-ok/20 text-ok", state === "now" && "bg-accent/20 text-accent", state === "wait" && "bg-raised text-subtle"),
								children: state === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : i + 1
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: state === "wait" ? "text-subtle" : "text-fg",
								children: label
							})]
						}, label);
					})
				}),
				done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tabular mt-4 font-mono text-sm text-muted",
					children: [
						formatMb(freedMb),
						" liberados · ",
						killed,
						" apps encerrados"
					]
				}) : null
			]
		})
	});
}
var TABS = [
	{
		to: "/",
		label: "Início",
		icon: Gauge
	},
	{
		to: "/jogos",
		label: "Jogos",
		icon: Gamepad2
	},
	{
		to: "/ferramentas",
		label: "Ferramentas",
		icon: Sparkles
	},
	{
		to: "/ajustes",
		label: "Ajustes",
		icon: Settings2
	}
];
function Shell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const battery = useBoost((s) => s.telemetry.battery);
	const charging = useBoost((s) => s.telemetry.charging);
	const boosting = useBoost((s) => s.boosting);
	const boostStep = useBoost((s) => s.boostStep);
	const lastFreed = useBoost((s) => s.lastFreedMb);
	const history0 = useBoost((s) => s.history[0]);
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 15e3);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh w-full max-w-lg flex-col bg-bg text-fg lg:border-x lg:border-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-5 pt-[max(0.75rem,env(safe-area-inset-top))] pb-1 text-xs text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular font-mono",
						children: now ? formatClock(now) : "--:--"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tracking-[0.18em] text-[0.65rem] uppercase",
						children: "Apex"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular font-mono",
						children: [
							charging ? "↯ " : "",
							battery,
							"%"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 px-5 pb-32",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: cn("fixed bottom-0 left-1/2 z-30 w-full max-w-lg -translate-x-1/2", "border-t border-border bg-bg/95 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-4",
					children: TABS.map((tab) => {
						const active = tab.to === "/" ? pathname === "/" : pathname.startsWith(tab.to);
						const Icon = tab.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: tab.to,
							className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-[0.68rem] tracking-wide", active ? "text-fg" : "text-subtle"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.2 : 1.7
							}), tab.label]
						}) }, tab.to);
					})
				})
			}),
			boosting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoostOverlay, {
				step: boostStep,
				done: boostStep >= 5,
				freedMb: lastFreed,
				killed: history0?.appsKilled ?? 0
			}) : null
		]
	});
}
//#endregion
export { formatMb as i, formatAgo as n, formatGb as r, Shell as t };
