import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Minimize2, f as Lock, g as CircleDot, i as Video, m as Gauge, p as Hand, s as Sun, v as Camera, y as BellOff } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useBoost, f as MODE_LABEL, i as acquireWakeLock, m as findGame, n as Route, o as targetFps } from "./router-DJZmLliy.mjs";
import { t as cn } from "./cn-Ccejyh36.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sessao._gameId-CbVnQSoz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var empty = {
	score: 0,
	combo: 0,
	hits: 0,
	misses: 0,
	latency: 0,
	fps: 60
};
function Arena({ mode, capFps, touchBoost, edgeProtect, onStats, canvasRef, variant = "tap" }) {
	const statsRef = (0, import_react.useRef)({ ...empty });
	const onStatsRef = (0, import_react.useRef)(onStats);
	onStatsRef.current = onStats;
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d", { alpha: false });
		if (!ctx) return;
		let raf = 0;
		let running = true;
		let last = performance.now();
		let acc = 0;
		let spawnAcc = 0;
		let nextId = 1;
		let frames = 0;
		let fpsStamp = performance.now();
		const targets = [];
		const particles = [];
		const stats = { ...empty };
		statsRef.current = stats;
		const resize = () => {
			const parent = canvas.parentElement;
			const w = parent?.clientWidth ?? 360;
			const h = parent?.clientHeight ?? 640;
			const dpr = Math.min(window.devicePixelRatio || 1, mode === "battery" ? 1 : 2);
			canvas.width = Math.floor(w * dpr);
			canvas.height = Math.floor(h * dpr);
			canvas.style.width = `${w}px`;
			canvas.style.height = `${h}px`;
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		};
		resize();
		const ro = new ResizeObserver(resize);
		if (canvas.parentElement) ro.observe(canvas.parentElement);
		const spawnRate = variant === "moba" ? 1.25 : mode === "performance" ? .92 : mode === "balanced" ? .7 : .48;
		const life = variant === "moba" ? 1100 : mode === "battery" ? 2200 : 1600;
		const particleN = mode === "performance" ? 10 : mode === "balanced" ? 5 : 0;
		const frameMs = 1e3 / Math.max(24, Math.min(60, capFps));
		const hitPad = 8 + touchBoost / 100 * 18;
		const bottomReserve = variant === "moba" ? 108 : 64;
		const maxTargets = variant === "moba" ? 7 : mode === "battery" ? 3 : 6;
		const spawn = (now) => {
			const w = canvas.clientWidth;
			const h = canvas.clientHeight;
			const pad = edgeProtect ? 28 : 12;
			targets.push({
				id: nextId++,
				x: pad + Math.random() * (w - pad * 2),
				y: pad + 48 + Math.random() * Math.max(80, h - pad * 2 - bottomReserve),
				r: variant === "moba" ? 14 + Math.random() * 10 : 28 + Math.random() * 16,
				born: now,
				life
			});
		};
		const hitAt = (x, y, now) => {
			const w = canvas.clientWidth;
			if (edgeProtect && (x < 18 || x > w - 18)) return;
			let best = -1;
			let bestD = 1e9;
			for (let i = 0; i < targets.length; i += 1) {
				const t = targets[i];
				if (!t) continue;
				const d = Math.hypot(t.x - x, t.y - y);
				if (d <= t.r + hitPad && d < bestD) {
					bestD = d;
					best = i;
				}
			}
			if (best < 0) {
				stats.combo = 0;
				stats.misses += 1;
				onStatsRef.current({ ...stats });
				return;
			}
			const t = targets[best];
			if (!t) return;
			stats.hits += 1;
			stats.combo += 1;
			stats.latency = Math.round(now - t.born);
			stats.score += 10 + stats.combo * 2;
			for (let i = 0; i < particleN; i += 1) {
				const a = Math.PI * 2 * i / particleN;
				particles.push({
					x: t.x,
					y: t.y,
					vx: Math.cos(a) * 2.4,
					vy: Math.sin(a) * 2.4,
					life: 1
				});
			}
			targets.splice(best, 1);
			onStatsRef.current({ ...stats });
		};
		const onPointer = (e) => {
			const rect = canvas.getBoundingClientRect();
			hitAt(e.clientX - rect.left, e.clientY - rect.top, performance.now());
		};
		canvas.addEventListener("pointerdown", onPointer);
		const loop = (now) => {
			if (!running) return;
			const dt = now - last;
			last = now;
			acc += dt;
			if (acc < frameMs) {
				raf = requestAnimationFrame(loop);
				return;
			}
			const step = Math.min(acc, 48);
			acc = 0;
			frames += 1;
			if (now - fpsStamp >= 400) {
				stats.fps = Math.round(frames * 1e3 / (now - fpsStamp));
				frames = 0;
				fpsStamp = now;
				onStatsRef.current({ ...stats });
			}
			spawnAcc += step * spawnRate;
			if (spawnAcc > 700 && targets.length < maxTargets) {
				spawn(now);
				spawnAcc = 0;
			}
			for (let i = targets.length - 1; i >= 0; i -= 1) {
				const t = targets[i];
				if (!t) continue;
				if (now - t.born > t.life) {
					targets.splice(i, 1);
					stats.combo = 0;
					stats.misses += 1;
				}
			}
			for (let i = particles.length - 1; i >= 0; i -= 1) {
				const p = particles[i];
				if (!p) continue;
				p.x += p.vx;
				p.y += p.vy;
				p.life -= .045;
				if (p.life <= 0) particles.splice(i, 1);
			}
			const w = canvas.clientWidth;
			const h = canvas.clientHeight;
			ctx.fillStyle = "#0b0c0e";
			ctx.fillRect(0, 0, w, h);
			ctx.strokeStyle = "rgba(236,238,240,0.04)";
			ctx.lineWidth = 1;
			for (let x = 0; x < w; x += 32) {
				ctx.beginPath();
				ctx.moveTo(x, 0);
				ctx.lineTo(x, h);
				ctx.stroke();
			}
			for (const t of targets) {
				const age = (now - t.born) / t.life;
				const rr = t.r * (1.15 - age * .35);
				ctx.beginPath();
				ctx.arc(t.x, t.y, rr, 0, Math.PI * 2);
				ctx.strokeStyle = `rgba(138,160,173,${.95 - age * .5})`;
				ctx.lineWidth = 2;
				ctx.stroke();
				ctx.beginPath();
				ctx.arc(t.x, t.y, Math.max(4, rr * (1 - age)), 0, Math.PI * 2);
				ctx.fillStyle = `rgba(138,160,173,${.18 - age * .1})`;
				ctx.fill();
			}
			for (const p of particles) {
				ctx.fillStyle = `rgba(236,238,240,${p.life})`;
				ctx.fillRect(p.x, p.y, 2, 2);
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => {
			running = false;
			cancelAnimationFrame(raf);
			canvas.removeEventListener("pointerdown", onPointer);
			ro.disconnect();
		};
	}, [
		mode,
		capFps,
		touchBoost,
		edgeProtect,
		canvasRef,
		variant
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvasRef,
		className: "absolute inset-0 h-full w-full touch-none"
	});
}
function GameTools({ fps, recording, onScreenshot, onRecord, onClose }) {
	const settings = useBoost((s) => s.settings);
	const toggle = useBoost((s) => s.togglePlugin);
	const [open, setOpen] = (0, import_react.useState)(true);
	const [side, setSide] = (0, import_react.useState)("right");
	(0, import_react.useEffect)(() => {
		if (settings.navLock) {
			const prev = document.body.style.overscrollBehavior;
			document.body.style.overscrollBehavior = "none";
			return () => {
				document.body.style.overscrollBehavior = prev;
			};
		}
	}, [settings.navLock]);
	const tools = [
		{
			id: "shot",
			label: "Captura",
			icon: Camera,
			on: false,
			action: onScreenshot
		},
		{
			id: "rec",
			label: recording ? "Parar" : "Gravar",
			icon: Video,
			on: recording,
			action: onRecord
		},
		{
			id: "dnd",
			label: "Não perturbe",
			icon: BellOff,
			on: settings.dnd,
			action: () => toggle("dnd")
		},
		{
			id: "fps",
			label: "FPS",
			icon: Gauge,
			on: settings.fpsCounter,
			action: () => toggle("fpsCounter")
		},
		{
			id: "touch",
			label: "Borda",
			icon: Hand,
			on: settings.touchProtect,
			action: () => toggle("touchProtect")
		},
		{
			id: "nav",
			label: "Navegação",
			icon: Lock,
			on: settings.navLock,
			action: () => toggle("navLock")
		},
		{
			id: "sun",
			label: "Tela on",
			icon: Sun,
			on: settings.brightnessLock,
			action: () => toggle("brightnessLock")
		},
		{
			id: "min",
			label: "Recolher",
			icon: Minimize2,
			on: false,
			action: () => setOpen(false)
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [settings.fpsCounter ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute top-3 left-3 z-40 rounded-md bg-bg/80 px-2 py-1 font-mono text-xs text-accent tabular",
		children: [fps, " FPS"]
	}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("absolute top-1/2 z-40 -translate-y-1/2", side === "right" ? "right-0" : "left-0"),
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("flex flex-col gap-1 bg-surface/95 p-1.5 shadow-[var(--shadow-border)]", side === "right" ? "rounded-l-xl" : "rounded-r-xl"),
			children: [
				tools.map((t) => {
					const Icon = t.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: t.action,
						title: t.label,
						className: cn("flex size-10 items-center justify-center rounded-md transition-colors duration-150", t.on ? "bg-fg text-accent-fg" : "text-muted hover:bg-raised hover:text-fg"),
						"aria-label": t.label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
					}, t.id);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-10 items-center justify-center rounded-md text-subtle hover:text-fg",
					onClick: () => setSide((s) => s === "right" ? "left" : "right"),
					"aria-label": "Trocar lado",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleDot, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-10 items-center justify-center rounded-md text-subtle hover:text-fg",
					onClick: onClose,
					"aria-label": "Sair do jogo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[0.65rem] tracking-wide",
						children: "SAIR"
					})
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setOpen(true),
			className: cn("flex h-16 w-6 items-center justify-center bg-accent text-accent-fg", side === "right" ? "rounded-l-md" : "rounded-r-md", recording && "bg-danger text-fg"),
			"aria-label": "Abrir Game Tools"
		})
	})] });
}
function Sessao() {
	const { gameId } = Route.useParams();
	const navigate = useNavigate();
	const custom = useBoost((s) => s.customGames);
	const game = (0, import_react.useMemo)(() => findGame(gameId, custom), [gameId, custom]);
	const mode = useBoost((s) => s.mode);
	const settings = useBoost((s) => s.settings);
	const addCapture = useBoost((s) => s.addCapture);
	const canvasRef = (0, import_react.useRef)(null);
	const recorderRef = (0, import_react.useRef)(null);
	const chunksRef = (0, import_react.useRef)([]);
	const lockRef = (0, import_react.useRef)(null);
	const [recording, setRecording] = (0, import_react.useState)(false);
	const [stats, setStats] = (0, import_react.useState)({
		score: 0,
		combo: 0,
		hits: 0,
		misses: 0,
		latency: 0,
		fps: 60
	});
	const [benchLeft, setBenchLeft] = (0, import_react.useState)(gameId === "bench" ? 15 : 0);
	const [benchDone, setBenchDone] = (0, import_react.useState)(null);
	const fpsLog = (0, import_react.useRef)([]);
	const cap = targetFps(mode);
	const isBench = gameId === "bench";
	const isMoba = game?.kind === "moba";
	const [armed, setArmed] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (gameId !== "hok" && game?.kind !== "moba") return;
		const s = useBoost.getState();
		if (s.mode === "performance" && s.settings.touchBoost >= 90 && s.settings.navLock) return;
		s.applyHokProfile();
	}, [gameId, game?.kind]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		if (settings.brightnessLock) acquireWakeLock().then((lock) => {
			if (cancelled) {
				lock?.release();
				return;
			}
			lockRef.current = lock;
		});
		return () => {
			cancelled = true;
			lockRef.current?.release();
			lockRef.current = null;
			if (recorderRef.current && recorderRef.current.state !== "inactive") recorderRef.current.stop();
		};
	}, [settings.brightnessLock]);
	const statsRef = (0, import_react.useRef)(stats);
	statsRef.current = stats;
	(0, import_react.useEffect)(() => {
		if (!isBench || benchDone) return void 0;
		setBenchLeft(15);
		fpsLog.current = [];
		const id = window.setInterval(() => {
			setBenchLeft((n) => {
				if (n <= 1) {
					window.clearInterval(id);
					const s = statsRef.current;
					const avg = fpsLog.current.length === 0 ? s.fps : Math.round(fpsLog.current.reduce((a, b) => a + b, 0) / fpsLog.current.length);
					setBenchDone({
						fps: avg,
						latency: s.latency,
						hits: s.hits
					});
					return 0;
				}
				return n - 1;
			});
		}, 1e3);
		return () => window.clearInterval(id);
	}, [isBench, benchDone]);
	const onStats = (s) => {
		fpsLog.current.push(s.fps);
		if (fpsLog.current.length > 40) fpsLog.current.shift();
		setStats(s);
	};
	const screenshot = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .82);
			addCapture({
				id: `s-${Date.now()}`,
				at: Date.now(),
				dataUrl,
				kind: "shot"
			});
			if (!settings.dnd) toast.success("Captura salva no álbum");
		} catch {
			toast.error("Não foi possível capturar");
		}
	};
	const toggleRecord = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		if (recording) {
			recorderRef.current?.stop();
			return;
		}
		try {
			const stream = canvas.captureStream(Math.min(60, cap));
			const rec = new MediaRecorder(stream, { mimeType: pickMime() });
			chunksRef.current = [];
			rec.ondataavailable = (e) => {
				if (e.data.size) chunksRef.current.push(e.data);
			};
			rec.onstop = () => {
				setRecording(false);
				const blob = new Blob(chunksRef.current, { type: rec.mimeType });
				const url = URL.createObjectURL(blob);
				const a = document.createElement("a");
				a.href = url;
				a.download = `apex-boost-${Date.now()}.webm`;
				a.click();
				URL.revokeObjectURL(url);
				const still = canvas.toDataURL("image/jpeg", .7);
				addCapture({
					id: `c-${Date.now()}`,
					at: Date.now(),
					dataUrl: still,
					kind: "clip"
				});
				if (!settings.dnd) toast.success("Clip baixado");
			};
			rec.start();
			recorderRef.current = rec;
			setRecording(true);
		} catch {
			toast.error("Gravação não suportada neste navegador");
		}
	};
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-bg px-6 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Jogo não encontrado." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "h-11 rounded-lg bg-fg px-4 text-accent-fg",
			onClick: () => navigate({ to: "/jogos" }),
			children: "Voltar"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto min-h-dvh w-full max-w-lg overflow-hidden bg-bg text-fg lg:border-x lg:border-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arena, {
				mode,
				capFps: cap,
				touchBoost: settings.touchBoost + (armed ? 18 : 0),
				edgeProtect: settings.touchProtect,
				onStats,
				canvasRef,
				variant: isMoba ? "moba" : "tap"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between px-4 pt-[max(0.75rem,env(safe-area-inset-top))]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.16em] text-subtle uppercase",
					children: game.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						MODE_LABEL[mode],
						" · ",
						60,
						" FPS travado"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-bg/70 px-2 py-1 text-right font-mono text-xs tabular",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [stats.score, " pts"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted",
						children: [stats.combo, "x"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-x-0 bottom-0 z-30 px-4 pb-[max(1rem,env(safe-area-inset-bottom))]",
				children: isMoba ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 flex justify-center gap-2",
					children: [
						"Q",
						"W",
						"E",
						"R"
					].map((sk) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setArmed((c) => c === sk ? null : sk),
						className: armed === sk ? "size-12 rounded-full bg-fg font-mono text-sm text-accent-fg" : "size-12 rounded-full bg-surface font-mono text-sm text-muted shadow-[var(--shadow-border)]",
						"aria-label": `Skill ${sk}`,
						children: sk
					}, sk))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-bg/75 px-4 py-3 text-xs text-muted",
					children: [
						"Lane 60 FPS · skills QWER · latência ",
						stats.latency || "—",
						" ms · ",
						stats.hits,
						" acertos"
					]
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none rounded-xl bg-bg/75 px-4 py-3 text-xs text-muted",
					children: isBench ? benchDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Média ",
						benchDone.fps,
						" FPS · latência ",
						benchDone.latency || "—",
						" ms · ",
						benchDone.hits,
						" ",
						"acertos"
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "tabular",
						children: [
							"Teste · ",
							benchLeft,
							"s · toque nos anéis"
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Toque nos anéis. Latência ",
						stats.latency || "—",
						" ms · ",
						stats.hits,
						" acertos ·",
						" ",
						stats.misses,
						" erros"
					] })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameTools, {
				fps: stats.fps,
				recording,
				onScreenshot: screenshot,
				onRecord: toggleRecord,
				onClose: () => navigate({ to: "/jogos" })
			})
		]
	});
}
function pickMime() {
	for (const t of [
		"video/webm;codecs=vp9",
		"video/webm;codecs=vp8",
		"video/webm"
	]) if (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(t)) return t;
	return "video/webm";
}
//#endregion
export { Sessao as component };
