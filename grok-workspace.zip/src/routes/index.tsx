import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Wifi } from "lucide-react";
import { useState } from "react";
import { ModePills } from "@/components/mode-pills";
import { RamGauge } from "@/components/ram-gauge";
import { Shell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { DEVICE, LOCKED_FPS, MODE_HINT } from "@/lib/games";
import { formatAgo, formatGb, formatMb } from "@/lib/format";
import { runBoostFlow } from "@/lib/run-boost-flow";
import { aliveRam, useBoost } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const navigate = useNavigate();
  const mode = useBoost((s) => s.mode);
  const setMode = useBoost((s) => s.setMode);
  const telemetry = useBoost((s) => s.telemetry);
  const processes = useBoost((s) => s.processes);
  const boosting = useBoost((s) => s.boosting);
  const history = useBoost((s) => s.history);
  const applyHok = useBoost((s) => s.applyHokProfile);
  const auto = useBoost((s) => s.settings.autoOptimize);
  const last = history[0];
  const background = processes.filter((p) => p.alive).length;
  const backgroundRam = aliveRam(processes);
  const ramPct = Math.round((telemetry.usedRamMb / DEVICE.ramMb) * 100);
  const tempTone =
    telemetry.temp >= 47 ? "text-danger" : telemetry.temp >= 41 ? "text-warn" : "text-ok";
  const [hokBusy, setHokBusy] = useState(false);

  const launchHok = async () => {
    setHokBusy(true);
    try {
      applyHok();
      if (auto) await runBoostFlow({ gameName: "Honor of Kings", mode: "performance" });
      await navigate({ to: "/sessao/$gameId", params: { gameId: "hok" } });
    } finally {
      setHokBusy(false);
    }
  };

  return (
    <Shell>
      <div className="pt-2">
        <p className="text-xs tracking-[0.18em] text-subtle uppercase">{DEVICE.name}</p>
        <h1 className="mt-1 text-3xl font-medium">Apex Boost</h1>
        <p className="mt-1 text-sm text-muted">
          {DEVICE.chipset} · {DEVICE.gpu} · {DEVICE.ramGb} GB
        </p>
      </div>

      <div className="mt-4">
        <RamGauge usedMb={telemetry.usedRamMb} pulse={boosting} />
      </div>

      <div className="mt-1 grid grid-cols-3 gap-2 text-center">
        <Stat label="Em uso" value={`${ramPct}%`} />
        <Stat label="Segundo plano" value={`${background}`} />
        <Stat label="Apps" value={formatMb(backgroundRam)} />
      </div>

      <div className="mt-5">
        <ModePills value={mode} onChange={setMode} />
        <p className="mt-2 text-sm text-muted">{MODE_HINT[mode]}</p>
      </div>

      <Button className="mt-4 w-full" size="lg" disabled={boosting} onClick={() => void runBoostFlow()}>
        Otimizar agora
      </Button>

      <button
        type="button"
        disabled={boosting || hokBusy}
        onClick={() => void launchHok()}
        className="mt-2 flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-border)] active:scale-[0.96]"
      >
        <span>
          <span className="block text-sm font-medium">Honor of Kings</span>
          <span className="block text-xs text-muted">Perfil MOBA · toque alto · DND</span>
        </span>
        <span className="font-mono text-sm text-accent tabular">{LOCKED_FPS} FPS</span>
      </button>

      <div className="mt-4 grid grid-cols-4 gap-2">
        <Chip label="CPU" value={`${telemetry.cpu}%`} />
        <Chip label="GPU" value={`${telemetry.gpu}%`} />
        <Chip label="Temp" value={`${telemetry.temp.toFixed(0)}°`} valueClass={tempTone} />
        <Chip label="Livre" value={formatGb(telemetry.storageFreeGb, 0)} />
      </div>

      <div className="mt-2 flex items-center justify-between rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]">
        <div className="flex items-center gap-3">
          <Wifi className="size-4 text-muted" />
          <p className="text-sm">Rede do A05s</p>
        </div>
        <span className="font-mono text-sm text-accent tabular">{telemetry.net}</span>
      </div>

      <p className="mt-4 rounded-xl bg-surface px-4 py-3 text-sm text-muted shadow-[var(--shadow-border)]">
        {last ? (
          <>
            Última: <span className="text-fg tabular">{formatMb(last.ramFreedMb)}</span> · {last.appsKilled} apps ·{" "}
            {formatAgo(last.at)}
          </>
        ) : (
          <>Toque em otimizar antes de um jogo pesado no Adreno 610.</>
        )}
      </p>
    </Shell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="tabular font-mono text-lg">{value}</p>
      <p className="text-[0.7rem] tracking-wide text-subtle uppercase">{label}</p>
    </div>
  );
}

function Chip({
  label,
  value,
  valueClass,
}: {
  label: string;
  value: string;
  valueClass?: string;
}) {
  return (
    <div className="rounded-xl bg-surface px-2 py-3 text-center shadow-[var(--shadow-border)]">
      <p className="text-[0.65rem] tracking-wide text-subtle uppercase">{label}</p>
      <p className={`tabular mt-1 font-mono text-sm ${valueClass ?? "text-fg"}`}>{value}</p>
    </div>
  );
}
