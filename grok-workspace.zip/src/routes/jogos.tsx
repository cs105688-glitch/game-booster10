import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Plus, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { Shell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { MODE_LABEL, WEIGHT_LABEL, CATALOG, type CatalogGame } from "@/lib/games";
import { runBoostFlow } from "@/lib/run-boost-flow";
import { useBoost } from "@/lib/store";
import { cn } from "@/lib/cn";

export const Route = createFileRoute("/jogos")({ component: Jogos });

function Jogos() {
  const navigate = useNavigate();
  const custom = useBoost((s) => s.customGames);
  const addGame = useBoost((s) => s.addGame);
  const removeGame = useBoost((s) => s.removeGame);
  const auto = useBoost((s) => s.settings.autoOptimize);
  const applyHok = useBoost((s) => s.applyHokProfile);
  const all = useMemo(() => [...custom, ...CATALOG], [custom]);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [busy, setBusy] = useState<string | null>(null);

  const launch = async (game: CatalogGame) => {
    setBusy(game.id);
    try {
      if (game.id === "hok" || game.kind === "moba") applyHok();
      if (auto) await runBoostFlow({ gameName: game.name, mode: game.rec });
      await navigate({ to: "/sessao/$gameId", params: { gameId: game.id } });
    } finally {
      setBusy(null);
    }
  };

  return (
    <Shell>
      <div className="flex items-end justify-between pt-3">
        <div>
          <p className="text-xs tracking-[0.18em] text-subtle uppercase">Game Launcher</p>
          <h1 className="mt-1 text-3xl font-medium">Jogos</h1>
        </div>
        <Button variant="outline" size="icon" onClick={() => setOpen(true)} aria-label="Adicionar jogo">
          <Plus className="size-4" />
        </Button>
      </div>
      <p className="mt-2 text-sm text-muted">
        Perfis calibrados para Adreno 610. Honor of Kings entra em 60 FPS travado, toque alto e DND.
      </p>

      <ul className="mt-6 space-y-2">
        {all.map((game) => {
          const customRow = custom.some((g) => g.id === game.id);
          return (
            <li
              key={game.id}
              className="flex items-center gap-3 rounded-xl bg-surface p-2 pl-3 shadow-[var(--shadow-border)]"
            >
              <div className="grid size-12 shrink-0 place-items-center rounded-lg bg-raised font-medium tracking-wide">
                {game.mark}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{game.name}</p>
                <p className="truncate text-xs text-muted">
                  {game.genre} · {WEIGHT_LABEL[game.weight]}
                </p>
              </div>
              <span
                className={cn(
                  "hidden rounded-full px-2 py-1 text-[0.65rem] tracking-wide uppercase sm:inline",
                  "bg-raised text-muted",
                )}
              >
                {MODE_LABEL[game.rec]}
              </span>
              {customRow ? (
                <button
                  type="button"
                  className="grid size-11 place-items-center text-subtle hover:text-danger"
                  onClick={() => removeGame(game.id)}
                  aria-label={`Remover ${game.name}`}
                >
                  <Trash2 className="size-4" />
                </button>
              ) : null}
              <Button
                size="sm"
                className="mr-1"
                disabled={busy === game.id}
                onClick={() => void launch(game)}
              >
                Jogar
              </Button>
            </li>
          );
        })}
      </ul>

      <Dialog open={open} onOpenChange={setOpen} title="Adicionar jogo">
        <label className="block text-sm text-muted" htmlFor="game-name">
          Nome
        </label>
        <input
          id="game-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ex.: Meu jogo"
          className="mt-2 h-11 w-full rounded-lg bg-raised px-3 text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle"
        />
        <Button
          className="mt-4 w-full"
          onClick={() => {
            addGame(name);
            setName("");
            setOpen(false);
          }}
        >
          Salvar na biblioteca
        </Button>
      </Dialog>
    </Shell>
  );
}
