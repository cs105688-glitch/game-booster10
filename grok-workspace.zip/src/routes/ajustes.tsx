import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { DEVICE, MODE_LABEL } from "@/lib/games";
import { formatMb } from "@/lib/format";
import { useBoost } from "@/lib/store";

export const Route = createFileRoute("/ajustes")({ component: Ajustes });

function Ajustes() {
  const settings = useBoost((s) => s.settings);
  const patch = useBoost((s) => s.patchSettings);
  const setTouch = useBoost((s) => s.setTouchBoost);
  const history = useBoost((s) => s.history);
  const telemetry = useBoost((s) => s.telemetry);

  const chart = [...history].slice(0, 12).reverse();
  const maxMb = Math.max(200, ...chart.map((h) => h.ramFreedMb));

  return (
    <Shell>
      <div className="pt-3">
        <p className="text-xs tracking-[0.18em] text-subtle uppercase">Perfil do aparelho</p>
        <h1 className="mt-1 text-3xl font-medium">Ajustes</h1>
      </div>

      <section className="mt-6 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
        <h2 className="text-lg font-medium">{DEVICE.name}</h2>
        <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
          <Row k="Chipset" v={DEVICE.chipset} />
          <Row k="GPU" v={DEVICE.gpu} />
          <Row k="CPU" v="8 núcleos" />
          <Row k="RAM" v={`${DEVICE.ramGb} GB`} />
          <Row k="Armazenamento" v={`${DEVICE.storageGb} GB`} />
          <Row k="Tela" v={DEVICE.display} />
          <Row k="Resolução" v={DEVICE.resolution} />
          <Row k="Alvo FPS" v="60 travado" />
          <Row k="Bateria" v={`${DEVICE.batteryMah} mAh`} />
        </dl>
        <p className="mt-4 text-xs text-muted">
          Núcleos visíveis neste aparelho: {telemetry.cores}. O booster assume o A05s mesmo se o
          navegador reportar outra memória.
        </p>
      </section>

      <section className="mt-5 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
        <h2 className="text-sm font-medium">Sensibilidade de toque</h2>
        <p className="mt-1 text-sm text-muted">
          Perfil MOBA: área de acerto maior para skills. Honor of Kings usa 92 por padrão.
        </p>
        <div className="mt-3">
          <Slider value={settings.touchBoost} onValueChange={setTouch} label="Sensibilidade" />
        </div>
        <p className="tabular mt-1 text-right font-mono text-xs text-subtle">{settings.touchBoost}</p>
        <div className="mt-4 flex items-center justify-between gap-3">
          <div>
            <p className="text-sm">Manter tela ligada</p>
            <p className="text-xs text-muted">Impede o A05s de apagar no jogo</p>
          </div>
          <Switch
            checked={settings.brightnessLock}
            onCheckedChange={(v) => patch({ brightnessLock: v })}
            label="Manter tela ligada"
          />
        </div>
      </section>

      <section className="mt-5 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
        <h2 className="text-sm font-medium">Memória liberada</h2>
        {chart.length === 0 ? (
          <p className="mt-3 text-sm text-muted">Rode o booster para ver o histórico.</p>
        ) : (
          <div className="mt-4 flex h-24 items-end gap-1">
            {chart.map((h, i) => (
              <div
                key={`${h.at}-${i}`}
                className="flex-1 rounded-sm bg-accent/80"
                style={{ height: `${Math.max(8, (h.ramFreedMb / maxMb) * 100)}%` }}
                title={formatMb(h.ramFreedMb)}
              />
            ))}
          </div>
        )}
        {history[0] ? (
          <p className="mt-3 text-xs text-muted">
            Último modo: {MODE_LABEL[history[0].mode]} · {formatMb(history[0].ramFreedMb)}
          </p>
        ) : null}
      </section>

      <p className="mt-6 pb-4 text-xs leading-relaxed text-subtle">
        O Apex Boost replica o fluxo do Game Booster — launcher, modos, overlay, DND, captura e limpeza
        de memória — dentro do app. Relógios de CPU do Android continuam com a Samsung; aqui o A05s
        ganha o painel, o perfil de 6 GB / Adreno 610 e as ferramentas de partida.
      </p>
    </Shell>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <dt className="text-xs text-subtle">{k}</dt>
      <dd className="mt-0.5">{v}</dd>
    </div>
  );
}
