import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BellOff,
  Camera,
  Gauge,
  Hand,
  Lock,
  Sun,
  Zap,
} from "lucide-react";
import { Shell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { formatAgo } from "@/lib/format";
import { useBoost, type PluginKey } from "@/lib/store";

export const Route = createFileRoute("/ferramentas")({ component: Ferramentas });

const PLUGINS: {
  key: Exclude<PluginKey, "touchBoost">;
  title: string;
  hint: string;
  icon: typeof Zap;
}[] = [
  { key: "dnd", title: "Não perturbe", hint: "Silencia toasts e alertas do booster durante a partida.", icon: BellOff },
  { key: "fpsCounter", title: "Contador de FPS", hint: "Overlay no canto, como no Game Tools da Samsung.", icon: Gauge },
  { key: "touchProtect", title: "Proteção de borda", hint: "Ignora toques acidentais nas laterais do A05s.", icon: Hand },
  { key: "navLock", title: "Bloquear navegação", hint: "Evita gesto de voltar encerrar a sessão.", icon: Lock },
  { key: "brightnessLock", title: "Manter tela ligada", hint: "Wake Lock para não apagar no meio da jogada.", icon: Sun },
  { key: "autoOptimize", title: "Otimizar ao abrir", hint: "Limpa RAM antes de cada jogo da biblioteca.", icon: Zap },
];

function Ferramentas() {
  const settings = useBoost((s) => s.settings);
  const toggle = useBoost((s) => s.togglePlugin);
  const captures = useBoost((s) => s.captures);
  const clear = useBoost((s) => s.clearCaptures);
  const processes = useBoost((s) => s.processes);
  const alive = processes.filter((p) => p.alive);

  return (
    <Shell>
      <div className="pt-3">
        <p className="text-xs tracking-[0.18em] text-subtle uppercase">Game Tools</p>
        <h1 className="mt-1 text-3xl font-medium">Ferramentas</h1>
        <p className="mt-2 text-sm text-muted">
        Os mesmos atalhos do Game Tools: captura, gravação, DND e FPS. Honor of Kings usa 60 FPS
        travado no Adreno 610.
        </p>
      </div>

      <Link
        to="/sessao/$gameId"
        params={{ gameId: "hok" }}
        className="mt-5 flex h-12 items-center justify-center rounded-xl bg-fg text-sm font-medium text-accent-fg"
      >
        Abrir perfil Honor of Kings
      </Link>

      <h2 className="mt-8 text-sm font-medium">Plugins</h2>
      <ul className="mt-3 space-y-2">
        {PLUGINS.map((p) => {
          const Icon = p.icon;
          const on = Boolean(settings[p.key]);
          return (
            <li
              key={p.key}
              className="flex items-center gap-3 rounded-xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]"
            >
              <span className="grid size-10 place-items-center rounded-lg bg-raised text-muted">
                <Icon className="size-4" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium">{p.title}</p>
                <p className="text-xs text-muted">{p.hint}</p>
              </div>
              <Switch
                checked={on}
                onCheckedChange={() => toggle(p.key)}
                label={p.title}
              />
            </li>
          );
        })}
      </ul>

      <h2 className="mt-8 text-sm font-medium">Álbum da partida</h2>
      {captures.length === 0 ? (
        <p className="mt-3 rounded-xl bg-surface px-4 py-3 text-sm text-muted shadow-[var(--shadow-border)]">
          Capturas e clips aparecem aqui depois que você usa Câmera ou Gravar no overlay.
        </p>
      ) : (
        <div className="mt-3">
          <div className="grid grid-cols-2 gap-2">
            {captures.map((c) => (
              <figure key={c.id} className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
                <img
                  src={c.dataUrl}
                  alt={c.kind === "shot" ? "Captura de tela" : "Quadro da gravação"}
                  className="aspect-video w-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
                />
                <figcaption className="flex items-center justify-between px-3 py-2 text-xs text-muted">
                  <span className="flex items-center gap-1">
                    {c.kind === "shot" ? <Camera className="size-3" /> : <Video className="size-3" />}
                    {c.kind === "shot" ? "Foto" : "Clip"}
                  </span>
                  {formatAgo(c.at)}
                </figcaption>
              </figure>
            ))}
          </div>
          <Button variant="ghost" className="mt-2 w-full" onClick={clear}>
            Limpar álbum
          </Button>
        </div>
      )}

      <h2 className="mt-8 text-sm font-medium">Segundo plano agora</h2>
      <ul className="mt-3 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]">
        {alive.slice(0, 8).map((p) => (
          <li key={p.id} className="flex items-center justify-between px-4 py-3 text-sm">
            <span>{p.name}</span>
            <span className="font-mono text-muted tabular">{p.ramMb} MB</span>
          </li>
        ))}
        {alive.length === 0 ? (
          <li className="px-4 py-3 text-sm text-muted">Nenhum app ocioso. Booster em efeito.</li>
        ) : null}
      </ul>
    </Shell>
  );
}
