import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Arena, type ArenaStats } from "@/components/arena";
import { GameTools } from "@/components/game-tools";
import { acquireWakeLock, targetFps } from "@/lib/boost";
import { findGame, LOCKED_FPS, MODE_LABEL } from "@/lib/games";
import { useBoost } from "@/lib/store";

export const Route = createFileRoute("/sessao/$gameId")({ component: Sessao });

function Sessao() {
  const { gameId } = Route.useParams();
  const navigate = useNavigate();
  const custom = useBoost((s) => s.customGames);
  const game = useMemo(() => findGame(gameId, custom), [gameId, custom]);
  const mode = useBoost((s) => s.mode);
  const settings = useBoost((s) => s.settings);
  const addCapture = useBoost((s) => s.addCapture);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const lockRef = useRef<WakeLockSentinel | null>(null);
  const [recording, setRecording] = useState(false);
  const [stats, setStats] = useState<ArenaStats>({
    score: 0,
    combo: 0,
    hits: 0,
    misses: 0,
    latency: 0,
    fps: 60,
  });
  const [benchLeft, setBenchLeft] = useState(gameId === "bench" ? 15 : 0);
  const [benchDone, setBenchDone] = useState<null | { fps: number; latency: number; hits: number }>(
    null,
  );
  const fpsLog = useRef<number[]>([]);

  const cap = targetFps(mode);
  const isBench = gameId === "bench";
  const isMoba = game?.kind === "moba";
  const [armed, setArmed] = useState<string | null>(null);

  useEffect(() => {
    if (gameId !== "hok" && game?.kind !== "moba") return;
    const s = useBoost.getState();
    if (s.mode === "performance" && s.settings.touchBoost >= 90 && s.settings.navLock) return;
    s.applyHokProfile();
  }, [gameId, game?.kind]);

  useEffect(() => {
    let cancelled = false;
    if (settings.brightnessLock) {
      void acquireWakeLock().then((lock) => {
        if (cancelled) {
          void lock?.release();
          return;
        }
        lockRef.current = lock;
      });
    }
    return () => {
      cancelled = true;
      void lockRef.current?.release();
      lockRef.current = null;
      if (recorderRef.current && recorderRef.current.state !== "inactive") {
        recorderRef.current.stop();
      }
    };
  }, [settings.brightnessLock]);

  const statsRef = useRef(stats);
  statsRef.current = stats;

  useEffect(() => {
    if (!isBench || benchDone) return undefined;
    setBenchLeft(15);
    fpsLog.current = [];
    const id = window.setInterval(() => {
      setBenchLeft((n) => {
        if (n <= 1) {
          window.clearInterval(id);
          const s = statsRef.current;
          const avg =
            fpsLog.current.length === 0
              ? s.fps
              : Math.round(fpsLog.current.reduce((a, b) => a + b, 0) / fpsLog.current.length);
          setBenchDone({ fps: avg, latency: s.latency, hits: s.hits });
          return 0;
        }
        return n - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [isBench, benchDone]);

  const onStats = (s: ArenaStats) => {
    fpsLog.current.push(s.fps);
    if (fpsLog.current.length > 40) fpsLog.current.shift();
    setStats(s);
  };

  const screenshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
      addCapture({ id: `s-${Date.now()}`, at: Date.now(), dataUrl, kind: "shot" });
      if (!settings.dnd) toast.success("Captura salva no álbum");
    } catch {
      toast.error("Não foi possível capturar");
    }
  };

  const toggleRecord = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (recording) {
      recorderRef.current?.stop();
      return;
    }
    try {
      const stream = canvas.captureStream(Math.min(60, cap));
      const rec = new MediaRecorder(stream, { mimeType: pickMime() });
      chunksRef.current = [];
      rec.ondataavailable = (e) => {
        if (e.data.size) chunksRef.current.push(e.data);
      };
      rec.onstop = () => {
        setRecording(false);
        const blob = new Blob(chunksRef.current, { type: rec.mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `apex-boost-${Date.now()}.webm`;
        a.click();
        URL.revokeObjectURL(url);
        const still = canvas.toDataURL("image/jpeg", 0.7);
        addCapture({ id: `c-${Date.now()}`, at: Date.now(), dataUrl: still, kind: "clip" });
        if (!settings.dnd) toast.success("Clip baixado");
      };
      rec.start();
      recorderRef.current = rec;
      setRecording(true);
    } catch {
      toast.error("Gravação não suportada neste navegador");
    }
  };

  if (!game) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-3 bg-bg px-6 text-fg">
        <p>Jogo não encontrado.</p>
        <button type="button" className="h-11 rounded-lg bg-fg px-4 text-accent-fg" onClick={() => navigate({ to: "/jogos" })}>
          Voltar
        </button>
      </div>
    );
  }

  return (
    <div className="relative mx-auto min-h-dvh w-full max-w-lg overflow-hidden bg-bg text-fg lg:border-x lg:border-border">
      <Arena
        mode={mode}
        capFps={cap}
        touchBoost={settings.touchBoost + (armed ? 18 : 0)}
        edgeProtect={settings.touchProtect}
        onStats={onStats}
        canvasRef={canvasRef}
        variant={isMoba ? "moba" : "tap"}
      />

      <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between px-4 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div>
          <p className="text-xs tracking-[0.16em] text-subtle uppercase">{game.name}</p>
          <p className="text-sm text-muted">
            {MODE_LABEL[mode]} · {LOCKED_FPS} FPS travado
          </p>
        </div>
        <div className="rounded-md bg-bg/70 px-2 py-1 text-right font-mono text-xs tabular">
          <p>{stats.score} pts</p>
          <p className="text-muted">{stats.combo}x</p>
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 z-30 px-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
        {isMoba ? (
          <div>
            <div className="mb-2 flex justify-center gap-2">
              {["Q", "W", "E", "R"].map((sk) => (
                <button
                  key={sk}
                  type="button"
                  onClick={() => setArmed((c) => (c === sk ? null : sk))}
                  className={
                    armed === sk
                      ? "size-12 rounded-full bg-fg font-mono text-sm text-accent-fg"
                      : "size-12 rounded-full bg-surface font-mono text-sm text-muted shadow-[var(--shadow-border)]"
                  }
                  aria-label={`Skill ${sk}`}
                >
                  {sk}
                </button>
              ))}
            </div>
            <div className="rounded-xl bg-bg/75 px-4 py-3 text-xs text-muted">
              Lane 60 FPS · skills QWER · latência {stats.latency || "—"} ms · {stats.hits} acertos
            </div>
          </div>
        ) : (
          <div className="pointer-events-none rounded-xl bg-bg/75 px-4 py-3 text-xs text-muted">
            {isBench ? (
              benchDone ? (
                <p>
                  Média {benchDone.fps} FPS · latência {benchDone.latency || "—"} ms · {benchDone.hits}{" "}
                  acertos
                </p>
              ) : (
                <p className="tabular">Teste · {benchLeft}s · toque nos anéis</p>
              )
            ) : (
              <p>
                Toque nos anéis. Latência {stats.latency || "—"} ms · {stats.hits} acertos ·{" "}
                {stats.misses} erros
              </p>
            )}
          </div>
        )}
      </div>

      <GameTools
        fps={stats.fps}
        recording={recording}
        onScreenshot={screenshot}
        onRecord={toggleRecord}
        onClose={() => navigate({ to: "/jogos" })}
      />
    </div>
  );
}

function pickMime(): string {
  const types = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"];
  for (const t of types) {
    if (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(t)) return t;
  }
  return "video/webm";
}
