import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  CATALOG,
  DEFAULT_PROCESSES,
  DEVICE,
  HOK_PROFILE,
  type BoostMode,
  type CatalogGame,
} from "@/lib/games";

export type PluginKey =
  | "dnd"
  | "fpsCounter"
  | "touchProtect"
  | "navLock"
  | "brightnessLock"
  | "autoOptimize"
  | "highRefresh"
  | "touchBoost";

export type Settings = {
  dnd: boolean;
  fpsCounter: boolean;
  touchProtect: boolean;
  navLock: boolean;
  brightnessLock: boolean;
  autoOptimize: boolean;
  highRefresh: boolean;
  touchBoost: number;
};

export type HistoryItem = {
  at: number;
  ramFreedMb: number;
  appsKilled: number;
  mode: BoostMode;
  gameName?: string;
};

export type Capture = {
  id: string;
  at: number;
  dataUrl: string;
  kind: "shot" | "clip";
};

export type LiveTelemetry = {
  fps: number;
  cpu: number;
  gpu: number;
  temp: number;
  battery: number;
  charging: boolean;
  usedRamMb: number;
  storageFreeGb: number;
  net: string;
  cores: number;
};

const defaultSettings = (): Settings => ({
  dnd: true,
  fpsCounter: true,
  touchProtect: true,
  navLock: true,
  brightnessLock: true,
  autoOptimize: true,
  highRefresh: false,
  touchBoost: 92,
});

export function spawnProcesses(): { id: string; name: string; ramMb: number; alive: boolean }[] {
  return DEFAULT_PROCESSES.map((p) => ({ ...p, alive: true }));
}

export type ProcessRow = { id: string; name: string; ramMb: number; alive: boolean };

type BoostState = {
  hydrated: boolean;
  mode: BoostMode;
  settings: Settings;
  customGames: CatalogGame[];
  history: HistoryItem[];
  processes: ProcessRow[];
  captures: Capture[];
  boosting: boolean;
  boostStep: number;
  lastFreedMb: number;
  telemetry: LiveTelemetry;
  setHydrated: (v: boolean) => void;
  setMode: (mode: BoostMode) => void;
  patchSettings: (patch: Partial<Settings>) => void;
  togglePlugin: (key: PluginKey) => void;
  setTouchBoost: (n: number) => void;
  addGame: (name: string) => void;
  removeGame: (id: string) => void;
  setProcesses: (rows: ProcessRow[]) => void;
  respawnSome: () => void;
  addHistory: (item: HistoryItem) => void;
  addCapture: (c: Capture) => void;
  clearCaptures: () => void;
  setBoosting: (v: boolean, step?: number) => void;
  setLastFreed: (n: number) => void;
  setTelemetry: (t: LiveTelemetry) => void;
  applyHokProfile: () => void;
  allGames: () => CatalogGame[];
};

export const initialTelemetry = (): LiveTelemetry => ({
  fps: 60,
  cpu: 28,
  gpu: 18,
  temp: 36.4,
  battery: 78,
  charging: false,
  usedRamMb: DEVICE.systemBaseMb + DEFAULT_PROCESSES.reduce((a, p) => a + p.ramMb, 0),
  storageFreeGb: 42.6,
  net: "4G",
  cores: 8,
});

export const useBoost = create<BoostState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      mode: "performance",
      settings: defaultSettings(),
      customGames: [],
      history: [],
      processes: spawnProcesses(),
      captures: [],
      boosting: false,
      boostStep: 0,
      lastFreedMb: 0,
      telemetry: initialTelemetry(),
      setHydrated: (v) => set({ hydrated: v }),
      setMode: (mode) => set({ mode }),
      patchSettings: (patch) => set({ settings: { ...get().settings, ...patch } }),
      togglePlugin: (key) => {
        if (key === "touchBoost") return;
        set({ settings: { ...get().settings, [key]: !get().settings[key] } });
      },
      setTouchBoost: (n) => set({ settings: { ...get().settings, touchBoost: n } }),
      addGame: (name) => {
        const trimmed = name.trim().slice(0, 28);
        if (!trimmed) return;
        const id = `c-${Date.now().toString(36)}`;
        const mark = trimmed
          .split(/\s+/)
          .slice(0, 2)
          .map((w) => w[0]?.toUpperCase() ?? "")
          .join("");
        set({
          customGames: [
            ...get().customGames,
            {
              id,
              name: trimmed,
              genre: "Seu jogo",
              weight: "medio",
              rec: get().mode,
              mark: mark || "JG",
            },
          ],
        });
      },
      removeGame: (id) =>
        set({ customGames: get().customGames.filter((g) => g.id !== id) }),
      setProcesses: (rows) => set({ processes: rows }),
      respawnSome: () => {
        const rows = get().processes.map((p) => {
          if (p.alive) return p;
          if (Math.random() > 0.18) return p;
          return { ...p, alive: true, ramMb: Math.round(p.ramMb * (0.55 + Math.random() * 0.35)) };
        });
        set({ processes: rows });
      },
      addHistory: (item) => set({ history: [item, ...get().history].slice(0, 24) }),
      addCapture: (c) => set({ captures: [c, ...get().captures].slice(0, 8) }),
      clearCaptures: () => set({ captures: [] }),
      setBoosting: (v, step = 0) => set({ boosting: v, boostStep: step }),
      setLastFreed: (n) => set({ lastFreedMb: n }),
      setTelemetry: (t) => set({ telemetry: t }),
      applyHokProfile: () =>
        set({
          mode: HOK_PROFILE.mode,
          settings: { ...HOK_PROFILE.settings },
        }),
      allGames: () => [...get().customGames, ...CATALOG],
    }),
    {
      name: "apex-boost-v2",
      partialize: (s) => ({
        mode: s.mode,
        settings: s.settings,
        customGames: s.customGames,
        history: s.history,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    },
  ),
);

export function aliveRam(rows: ProcessRow[]): number {
  return rows.filter((p) => p.alive).reduce((a, p) => a + p.ramMb, 0);
}
