import { useEffect } from "react";
import { DEVICE, LOCKED_FPS } from "@/lib/games";
import { estimateStorageFreeGb, heapMb, targetFps, usedRamMb } from "@/lib/boost";
import { useBoost } from "@/lib/store";

type NavConn = { effectiveType?: string; downlink?: number };
type BatteryLike = {
  level: number;
  charging: boolean;
  addEventListener: (name: string, fn: () => void) => void;
  removeEventListener: (name: string, fn: () => void) => void;
};

export function useTelemetryLoop() {
  useEffect(() => {
    let raf = 0;
    let frames = 0;
    let last = performance.now();
    let fps = 60;
    let cpuEma = 28;
    let gpuEma = 18;
    let tempEma = 36.4;
    let battery = 78;
    let charging = false;
    let storageFreeGb = 42.6;
    let net = "4G";
    let bat: BatteryLike | null = null;
    let dead = false;

    const nav = navigator as Navigator & {
      getBattery?: () => Promise<BatteryLike>;
      connection?: NavConn;
      deviceMemory?: number;
    };

    const onBat = () => {
      if (!bat) return;
      battery = Math.round(bat.level * 100);
      charging = bat.charging;
    };

    nav.getBattery?.()
      .then((b) => {
        bat = b;
        onBat();
        b.addEventListener("levelchange", onBat);
        b.addEventListener("chargingchange", onBat);
      })
      .catch(() => undefined);

    estimateStorageFreeGb().then((v) => {
      storageFreeGb = v;
    });

    const conn = nav.connection;
    if (conn?.effectiveType) {
      net = conn.effectiveType.toUpperCase();
    }

    const cores = navigator.hardwareConcurrency || 8;

    const tick = (now: number) => {
      frames += 1;
      const dt = now - last;
      if (dt >= 500) {
        fps = Math.round((frames * 1000) / dt);
        frames = 0;
        last = now;

        const { mode, processes, boosting } = useBoost.getState();
        const load =
          mode === "performance" ? 0.72 : mode === "balanced" ? 0.48 : 0.28;
        const extra = boosting ? 0.18 : 0;
        cpuEma = cpuEma * 0.72 + (18 + load * 62 + extra * 20 + Math.random() * 6) * 0.28;
        gpuEma = gpuEma * 0.72 + (10 + load * 70 + extra * 14 + Math.random() * 5) * 0.28;
        const thermal =
          34.2 +
          load * 10 +
          extra * 3 +
          (charging ? 1.4 : 0) +
          Math.sin(now / 9000) * 0.6;
        tempEma = tempEma * 0.85 + thermal * 0.15;

        const used = usedRamMb(processes, heapMb(), load + extra);
        const cap = targetFps(mode);

        useBoost.getState().setTelemetry({
          fps: Math.max(24, Math.min(cap, fps, LOCKED_FPS)),
          cpu: Math.round(Math.min(97, cpuEma)),
          gpu: Math.round(Math.min(97, gpuEma)),
          temp: Math.round(tempEma * 10) / 10,
          battery,
          charging,
          usedRamMb: used,
          storageFreeGb,
          net,
          cores: cores || DEVICE.ramGb + 2,
        });
      }
      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);

    const respawn = window.setInterval(() => {
      if (dead) return;
      if (document.hidden) return;
      useBoost.getState().respawnSome();
    }, 11000);

    return () => {
      dead = true;
      cancelAnimationFrame(raf);
      window.clearInterval(respawn);
      if (bat) {
        bat.removeEventListener("levelchange", onBat);
        bat.removeEventListener("chargingchange", onBat);
      }
    };
  }, []);
}
