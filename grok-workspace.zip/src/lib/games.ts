export type GameWeight = "leve" | "medio" | "pesado";
export type BoostMode = "performance" | "balanced" | "battery";
export type GameKind = "tap" | "moba" | "bench";

export type CatalogGame = {
  id: string;
  name: string;
  genre: string;
  weight: GameWeight;
  rec: BoostMode;
  mark: string;
  play?: string;
  builtin?: boolean;
  kind?: GameKind;
};

export const DEVICE = {
  name: "Galaxy A05s",
  chipset: "Snapdragon 680",
  cpu: "8 núcleos · 4×2,4 + 4×1,9 GHz",
  gpu: "Adreno 610",
  ramGb: 6,
  ramMb: 6144,
  storageGb: 128,
  display: "6,7\" HD+ 90 Hz",
  resolution: "720 × 1600",
  batteryMah: 5000,
  systemBaseMb: 2140,
} as const;

export const LOCKED_FPS = 60;

export const HOK_PROFILE = {
  mode: "performance" as BoostMode,
  settings: {
    dnd: true,
    fpsCounter: true,
    touchProtect: true,
    navLock: true,
    brightnessLock: true,
    autoOptimize: true,
    highRefresh: false,
    touchBoost: 92,
  },
};

export const CATALOG: CatalogGame[] = [
  {
    id: "hok",
    name: "Honor of Kings",
    genre: "MOBA",
    weight: "medio",
    rec: "performance",
    mark: "HK",
    kind: "moba",
    play: "https://play.google.com/store/apps/details?id=com.levelinfinite.sgameGlobal",
  },
  {
    id: "arena",
    name: "Apex Arena",
    genre: "Toque / treino",
    weight: "leve",
    rec: "performance",
    mark: "AA",
    builtin: true,
    kind: "tap",
  },
  {
    id: "bench",
    name: "Teste de desempenho",
    genre: "Diagnóstico",
    weight: "medio",
    rec: "performance",
    mark: "TD",
    builtin: true,
    kind: "bench",
  },
  {
    id: "freefire",
    name: "Free Fire",
    genre: "Battle royale",
    weight: "leve",
    rec: "performance",
    mark: "FF",
    play: "https://play.google.com/store/apps/details?id=com.dts.freefireth",
  },
  {
    id: "stumble",
    name: "Stumble Guys",
    genre: "Party",
    weight: "leve",
    rec: "balanced",
    mark: "SG",
    play: "https://play.google.com/store/apps/details?id=com.kitkagames.fallbuddies",
  },
  {
    id: "subway",
    name: "Subway Surfers",
    genre: "Runner",
    weight: "leve",
    rec: "balanced",
    mark: "SS",
    play: "https://play.google.com/store/apps/details?id=com.kiloo.subwaysurf",
  },
  {
    id: "clash",
    name: "Clash of Clans",
    genre: "Estratégia",
    weight: "leve",
    rec: "balanced",
    mark: "CC",
    play: "https://play.google.com/store/apps/details?id=com.supercell.clashofclans",
  },
  {
    id: "efootball",
    name: "eFootball",
    genre: "Esporte",
    weight: "medio",
    rec: "performance",
    mark: "EF",
    play: "https://play.google.com/store/apps/details?id=jp.konami.pesam",
  },
  {
    id: "mlbb",
    name: "Mobile Legends",
    genre: "MOBA",
    weight: "medio",
    rec: "performance",
    mark: "ML",
    kind: "moba",
    play: "https://play.google.com/store/apps/details?id=com.mobile.legends",
  },
  {
    id: "roblox",
    name: "Roblox",
    genre: "Sandbox",
    weight: "medio",
    rec: "balanced",
    mark: "RB",
    play: "https://play.google.com/store/apps/details?id=com.roblox.client",
  },
  {
    id: "among",
    name: "Among Us",
    genre: "Party",
    weight: "leve",
    rec: "battery",
    mark: "AU",
    play: "https://play.google.com/store/apps/details?id=com.innersloth.amongus",
  },
  {
    id: "pubg",
    name: "PUBG Mobile",
    genre: "Battle royale",
    weight: "pesado",
    rec: "balanced",
    mark: "PG",
    play: "https://play.google.com/store/apps/details?id=com.tencent.ig",
  },
  {
    id: "codm",
    name: "Call of Duty",
    genre: "Tiro",
    weight: "pesado",
    rec: "balanced",
    mark: "CD",
    play: "https://play.google.com/store/apps/details?id=com.activision.callofduty.shooter",
  },
];

export const WEIGHT_LABEL: Record<GameWeight, string> = {
  leve: "Leve no A05s",
  medio: "Médio no A05s",
  pesado: "Pesado no Adreno 610",
};

export const MODE_LABEL: Record<BoostMode, string> = {
  performance: "Desempenho",
  balanced: "Padrão",
  battery: "Economia",
};

export const MODE_HINT: Record<BoostMode, string> = {
  performance: "60 FPS travado. Núcleos Gold e toque alto para MOBA. Consome mais bateria.",
  balanced: "60 FPS estável, RAM limpa, temperatura controlada no A05s.",
  battery: "30 FPS, menos efeitos, prioriza os 5000 mAh.",
};

export type BgProcess = {
  id: string;
  name: string;
  ramMb: number;
};

export const DEFAULT_PROCESSES: BgProcess[] = [
  { id: "wa", name: "WhatsApp", ramMb: 312 },
  { id: "ig", name: "Instagram", ramMb: 268 },
  { id: "ch", name: "Chrome (abas)", ramMb: 410 },
  { id: "yt", name: "YouTube", ramMb: 224 },
  { id: "fb", name: "Facebook", ramMb: 198 },
  { id: "tt", name: "TikTok", ramMb: 256 },
  { id: "gm", name: "Gmail", ramMb: 94 },
  { id: "sp", name: "Spotify", ramMb: 118 },
  { id: "tg", name: "Telegram", ramMb: 142 },
  { id: "si", name: "Samsung Internet", ramMb: 176 },
  { id: "ms", name: "Mensagens", ramMb: 62 },
  { id: "ph", name: "Galeria", ramMb: 88 },
  { id: "pl", name: "Play Services", ramMb: 154 },
  { id: "sy", name: "Cache do sistema", ramMb: 210 },
];

export function findGame(id: string, extra: CatalogGame[] = []): CatalogGame | undefined {
  return extra.find((g) => g.id === id) ?? CATALOG.find((g) => g.id === id);
}
