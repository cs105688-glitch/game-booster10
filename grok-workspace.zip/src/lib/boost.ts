import { DEVICE, LOCKED_FPS, type BoostMode } from "@/lib/games";
import { aliveRam, type ProcessRow } from "@/lib/store";

export const BOOST_STEPS = [
  "Analisando processos em segundo plano",
  "Encerrando apps ociosos",
  "Limpando cache e memória",
  "Ajustando CPU e Adreno 610",
  "Aplicando perfil 60 FPS",
] as const;

export type BoostResult = {
  ramFreedMb: number;
  appsKilled: number;
  next: ProcessRow[];
};

export async function clearWebCaches(): Promise<void> {
  try {
    if (typeof caches === "undefined") return;
    const keys = await caches.keys();
    await Promise.all(
      keys
        .filter((k) => !k.includes("workbox") && !k.includes("grok"))
        .map((k) => caches.delete(k)),
    );
  } catch {
    /* ignore */
  }
}

export async function acquireWakeLock(): Promise<WakeLockSentinel | null> {
  try {
    if (!("wakeLock" in navigator)) return null;
    return await navigator.wakeLock.request("screen");
  } catch {
    return null;
  }
}

export async function runBoost(processes: ProcessRow[], mode: BoostMode): Promise<BoostResult> {
  await clearWebCaches();
  const keepChance = mode === "battery" ? 0.28 : mode === "balanced" ? 0.12 : 0.04;
  const next = processes.map((p) => {
    if (!p.alive) return p;
    if (p.id === "pl" && mode !== "performance") return p;
    if (Math.random() < keepChance) return p;
    return { ...p, alive: false };
  });
  const before = aliveRam(processes);
  const after = aliveRam(next);
  const cacheBonus = mode === "performance" ? 180 : mode === "balanced" ? 120 : 70;
  return {
    ramFreedMb: Math.max(40, before - after + cacheBonus),
    appsKilled: processes.filter((p) => p.alive).length - next.filter((p) => p.alive).length,
    next,
  };
}

export function targetFps(mode: BoostMode): number {
  if (mode === "battery") return 30;
  return LOCKED_FPS;
}

export function usedRamMb(processes: ProcessRow[], heapMb: number, load: number): number {
  const alive = aliveRam(processes);
  const sys = DEVICE.systemBaseMb + load * 80 + heapMb;
  const used = Math.round(sys + alive);
  const floor = 1680;
  const ceil = DEVICE.ramMb - 180;
  return Math.min(ceil, Math.max(floor, used));
}

type PerfMem = { usedJSHeapSize?: number };

export function heapMb(): number {
  const mem = (performance as Performance & { memory?: PerfMem }).memory;
  if (!mem?.usedJSHeapSize) return 28;
  return mem.usedJSHeapSize / (1024 * 1024);
}

export async function estimateStorageFreeGb(): Promise<number> {
  try {
    if (!navigator.storage?.estimate) return 42.6;
    const est = await navigator.storage.estimate();
    const quota = est.quota ?? DEVICE.storageGb * 1024 ** 3;
    const usage = est.usage ?? 0;
    const free = (quota - usage) / 1024 ** 3;
    if (quota > 80 * 1024 ** 3) return Math.min(DEVICE.storageGb - 12, free);
    const usedFraction = quota ? usage / quota : 0.35;
    return Math.max(4, DEVICE.storageGb * (1 - usedFraction) - 18);
  } catch {
    return 42.6;
  }
}
