import { BOOST_STEPS, runBoost } from "@/lib/boost";
import { useBoost } from "@/lib/store";
import type { BoostMode } from "@/lib/games";

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function runBoostFlow(opts?: { gameName?: string; mode?: BoostMode }) {
  const store = useBoost.getState();
  if (store.boosting) return null;
  const mode = opts?.mode ?? store.mode;
  store.setBoosting(true, 0);
  try {
    if (typeof navigator.vibrate === "function") navigator.vibrate(12);
    for (let i = 0; i < BOOST_STEPS.length; i += 1) {
      store.setBoosting(true, i);
      await sleep(420);
    }
    const result = await runBoost(useBoost.getState().processes, mode);
    store.setProcesses(result.next);
    store.setLastFreed(result.ramFreedMb);
    store.addHistory({
      at: Date.now(),
      ramFreedMb: result.ramFreedMb,
      appsKilled: result.appsKilled,
      mode,
      gameName: opts?.gameName,
    });
    store.setBoosting(true, BOOST_STEPS.length);
    await sleep(700);
    return result;
  } finally {
    useBoost.getState().setBoosting(false, 0);
  }
}
