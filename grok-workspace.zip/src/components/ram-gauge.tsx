import { DEVICE } from "@/lib/games";
import { formatMb } from "@/lib/format";
import { cn } from "@/lib/cn";

export function RamGauge({ usedMb, pulse }: { usedMb: number; pulse?: boolean }) {
  const total = DEVICE.ramMb;
  const free = Math.max(0, total - usedMb);
  const pct = Math.min(1, usedMb / total);
  const r = 86;
  const c = 2 * Math.PI * r;
  const dash = c * pct;
  const tone = pct > 0.86 ? "text-danger" : pct > 0.72 ? "text-warn" : "text-accent";

  return (
    <div className="relative mx-auto grid place-items-center">
      <svg viewBox="0 0 200 200" className={cn("size-44 sm:size-56", pulse && "animate-pulse")} aria-hidden>
        <circle cx="100" cy="100" r={r} fill="none" stroke="var(--color-raised)" strokeWidth="12" />
        <circle
          cx="100"
          cy="100"
          r={r}
          fill="none"
          className={cn("gauge-ring", tone)}
          stroke="currentColor"
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${c - dash}`}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <p className="text-xs tracking-[0.16em] text-subtle uppercase">RAM livre</p>
        <p className="tabular mt-1 font-mono text-3xl font-medium tracking-tight sm:text-4xl">{formatMb(free)}</p>
        <p className="tabular mt-1 text-sm text-muted">de {DEVICE.ramGb} GB</p>
      </div>
    </div>
  );
}
