import { Link, useRouterState } from "@tanstack/react-router";
import { Gamepad2, Gauge, Settings2, Sparkles } from "lucide-react";
import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import { BoostOverlay } from "@/components/boost-overlay";
import { cn } from "@/lib/cn";
import { formatClock } from "@/lib/format";
import { useBoost } from "@/lib/store";

const TABS = [
  { to: "/", label: "Início", icon: Gauge },
  { to: "/jogos", label: "Jogos", icon: Gamepad2 },
  { to: "/ferramentas", label: "Ferramentas", icon: Sparkles },
  { to: "/ajustes", label: "Ajustes", icon: Settings2 },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const battery = useBoost((s) => s.telemetry.battery);
  const charging = useBoost((s) => s.telemetry.charging);
  const boosting = useBoost((s) => s.boosting);
  const boostStep = useBoost((s) => s.boostStep);
  const lastFreed = useBoost((s) => s.lastFreedMb);
  const history0 = useBoost((s) => s.history[0]);
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const id = window.setInterval(() => setNow(new Date()), 15000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col bg-bg text-fg lg:border-x lg:border-border">
      <header className="flex items-center justify-between px-5 pt-[max(0.75rem,env(safe-area-inset-top))] pb-1 text-xs text-muted">
        <span className="tabular font-mono">{now ? formatClock(now) : "--:--"}</span>
        <span className="tracking-[0.18em] text-[0.65rem] uppercase">Apex</span>
        <span className="tabular font-mono">
          {charging ? "↯ " : ""}
          {battery}%
        </span>
      </header>
      <main className="flex-1 px-5 pb-32">{children}</main>
      <nav
        className={cn(
          "fixed bottom-0 left-1/2 z-30 w-full max-w-lg -translate-x-1/2",
          "border-t border-border bg-bg/95 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1",
        )}
      >
        <ul className="grid grid-cols-4">
          {TABS.map((tab) => {
            const active = tab.to === "/" ? pathname === "/" : pathname.startsWith(tab.to);
            const Icon = tab.icon;
            return (
              <li key={tab.to}>
                <Link
                  to={tab.to}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-1 text-[0.68rem] tracking-wide",
                    active ? "text-fg" : "text-subtle",
                  )}
                >
                  <Icon className="size-5" strokeWidth={active ? 2.2 : 1.7} />
                  {tab.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      {boosting ? (
        <BoostOverlay
          step={boostStep}
          done={boostStep >= 5}
          freedMb={lastFreed}
          killed={history0?.appsKilled ?? 0}
        />
      ) : null}
    </div>
  );
}
