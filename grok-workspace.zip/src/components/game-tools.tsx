import {
  BellOff,
  Camera,
  CircleDot,
  Gauge,
  Hand,
  Lock,
  Minimize2,
  Sun,
  Video,
} from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/cn";
import { useBoost } from "@/lib/store";

type Tool = {
  id: string;
  label: string;
  icon: typeof Camera;
  on: boolean;
  action: () => void;
};

export function GameTools({
  fps,
  recording,
  onScreenshot,
  onRecord,
  onClose,
}: {
  fps: number;
  recording: boolean;
  onScreenshot: () => void;
  onRecord: () => void;
  onClose: () => void;
}) {
  const settings = useBoost((s) => s.settings);
  const toggle = useBoost((s) => s.togglePlugin);
  const [open, setOpen] = useState(true);
  const [side, setSide] = useState<"left" | "right">("right");

  useEffect(() => {
    if (settings.navLock) {
      const prev = document.body.style.overscrollBehavior;
      document.body.style.overscrollBehavior = "none";
      return () => {
        document.body.style.overscrollBehavior = prev;
      };
    }
    return undefined;
  }, [settings.navLock]);

  const tools: Tool[] = [
    { id: "shot", label: "Captura", icon: Camera, on: false, action: onScreenshot },
    { id: "rec", label: recording ? "Parar" : "Gravar", icon: Video, on: recording, action: onRecord },
    { id: "dnd", label: "Não perturbe", icon: BellOff, on: settings.dnd, action: () => toggle("dnd") },
    {
      id: "fps",
      label: "FPS",
      icon: Gauge,
      on: settings.fpsCounter,
      action: () => toggle("fpsCounter"),
    },
    {
      id: "touch",
      label: "Borda",
      icon: Hand,
      on: settings.touchProtect,
      action: () => toggle("touchProtect"),
    },
    { id: "nav", label: "Navegação", icon: Lock, on: settings.navLock, action: () => toggle("navLock") },
    {
      id: "sun",
      label: "Tela on",
      icon: Sun,
      on: settings.brightnessLock,
      action: () => toggle("brightnessLock"),
    },
    { id: "min", label: "Recolher", icon: Minimize2, on: false, action: () => setOpen(false) },
  ];

  return (
    <>
      {settings.fpsCounter ? (
        <div className="pointer-events-none absolute top-3 left-3 z-40 rounded-md bg-bg/80 px-2 py-1 font-mono text-xs text-accent tabular">
          {fps} FPS
        </div>
      ) : null}

      <div
        className={cn(
          "absolute top-1/2 z-40 -translate-y-1/2",
          side === "right" ? "right-0" : "left-0",
        )}
      >
        {open ? (
          <div
            className={cn(
              "flex flex-col gap-1 bg-surface/95 p-1.5 shadow-[var(--shadow-border)]",
              side === "right" ? "rounded-l-xl" : "rounded-r-xl",
            )}
          >
            {tools.map((t) => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={t.action}
                  title={t.label}
                  className={cn(
                    "flex size-10 items-center justify-center rounded-md transition-colors duration-150",
                    t.on ? "bg-fg text-accent-fg" : "text-muted hover:bg-raised hover:text-fg",
                  )}
                  aria-label={t.label}
                >
                  <Icon className="size-4" />
                </button>
              );
            })}
            <button
              type="button"
              className="flex size-10 items-center justify-center rounded-md text-subtle hover:text-fg"
              onClick={() => setSide((s) => (s === "right" ? "left" : "right"))}
              aria-label="Trocar lado"
            >
              <CircleDot className="size-4" />
            </button>
            <button
              type="button"
              className="flex size-10 items-center justify-center rounded-md text-subtle hover:text-fg"
              onClick={onClose}
              aria-label="Sair do jogo"
            >
              <span className="text-[0.65rem] tracking-wide">SAIR</span>
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setOpen(true)}
            className={cn(
              "flex h-16 w-6 items-center justify-center bg-accent text-accent-fg",
              side === "right" ? "rounded-l-md" : "rounded-r-md",
              recording && "bg-danger text-fg",
            )}
            aria-label="Abrir Game Tools"
          />
        )}
      </div>
    </>
  );
}
