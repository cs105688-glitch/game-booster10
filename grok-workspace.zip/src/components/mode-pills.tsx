import { MODE_LABEL, type BoostMode } from "@/lib/games";
import { cn } from "@/lib/cn";

const ORDER: BoostMode[] = ["performance", "balanced", "battery"];

export function ModePills({
  value,
  onChange,
}: {
  value: BoostMode;
  onChange: (m: BoostMode) => void;
}) {
  return (
    <div className="grid grid-cols-3 gap-2 rounded-xl bg-surface p-1.5 shadow-[var(--shadow-border)]">
      {ORDER.map((m) => {
        const active = m === value;
        return (
          <button
            key={m}
            type="button"
            onClick={() => onChange(m)}
            className={cn(
              "h-11 rounded-lg text-sm font-medium transition-[background-color,color,transform] duration-150",
              "active:scale-[0.96]",
              active ? "bg-fg text-accent-fg" : "text-muted hover:text-fg",
            )}
          >
            {MODE_LABEL[m]}
          </button>
        );
      })}
    </div>
  );
}
