import { Check } from "lucide-react";
import { BOOST_STEPS } from "@/lib/boost";
import { cn } from "@/lib/cn";
import { formatMb } from "@/lib/format";

export function BoostOverlay({
  step,
  done,
  freedMb,
  killed,
}: {
  step: number;
  done: boolean;
  freedMb: number;
  killed: number;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-bg/80 p-5">
      <div className="w-full max-w-lg rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
        <p className="text-xs tracking-[0.18em] text-subtle uppercase">Game Booster</p>
        <h2 className="mt-1 text-xl font-medium">
          {done ? "Aparelho otimizado" : "Otimizando o A05s"}
        </h2>
        <ol className="mt-4 space-y-2">
          {BOOST_STEPS.map((label, i) => {
            const state = done || i < step ? "done" : i === step ? "now" : "wait";
            return (
              <li key={label} className="flex items-center gap-3 text-sm">
                <span
                  className={cn(
                    "grid size-7 place-items-center rounded-full",
                    state === "done" && "bg-ok/20 text-ok",
                    state === "now" && "bg-accent/20 text-accent",
                    state === "wait" && "bg-raised text-subtle",
                  )}
                >
                  {state === "done" ? <Check className="size-3.5" /> : i + 1}
                </span>
                <span className={state === "wait" ? "text-subtle" : "text-fg"}>{label}</span>
              </li>
            );
          })}
        </ol>
        {done ? (
          <p className="tabular mt-4 font-mono text-sm text-muted">
            {formatMb(freedMb)} liberados · {killed} apps encerrados
          </p>
        ) : null}
      </div>
    </div>
  );
}
