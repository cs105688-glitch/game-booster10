import { useEffect, useRef, type RefObject } from "react";
import type { BoostMode } from "@/lib/games";

type Target = {
  x: number;
  y: number;
  r: number;
  born: number;
  life: number;
  id: number;
};

type Particle = { x: number; y: number; vx: number; vy: number; life: number };

export type ArenaStats = {
  score: number;
  combo: number;
  hits: number;
  misses: number;
  latency: number;
  fps: number;
};

const empty: ArenaStats = { score: 0, combo: 0, hits: 0, misses: 0, latency: 0, fps: 60 };

export function Arena({
  mode,
  capFps,
  touchBoost,
  edgeProtect,
  onStats,
  canvasRef,
  variant = "tap",
}: {
  mode: BoostMode;
  capFps: number;
  touchBoost: number;
  edgeProtect: boolean;
  onStats: (s: ArenaStats) => void;
  canvasRef: RefObject<HTMLCanvasElement | null>;
  variant?: "tap" | "moba";
}) {
  const statsRef = useRef<ArenaStats>({ ...empty });
  const onStatsRef = useRef(onStats);
  onStatsRef.current = onStats;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;

    let raf = 0;
    let running = true;
    let last = performance.now();
    let acc = 0;
    let spawnAcc = 0;
    let nextId = 1;
    let frames = 0;
    let fpsStamp = performance.now();
    const targets: Target[] = [];
    const particles: Particle[] = [];
    const stats = { ...empty };
    statsRef.current = stats;

    const resize = () => {
      const parent = canvas.parentElement;
      const w = parent?.clientWidth ?? 360;
      const h = parent?.clientHeight ?? 640;
      const dpr = Math.min(window.devicePixelRatio || 1, mode === "battery" ? 1 : 2);
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    if (canvas.parentElement) ro.observe(canvas.parentElement);

    const spawnRate = variant === "moba" ? 1.25 : mode === "performance" ? 0.92 : mode === "balanced" ? 0.7 : 0.48;
    const life = variant === "moba" ? 1100 : mode === "battery" ? 2200 : 1600;
    const particleN = mode === "performance" ? 10 : mode === "balanced" ? 5 : 0;
    const frameMs = 1000 / Math.max(24, Math.min(60, capFps));
    const hitPad = 8 + (touchBoost / 100) * 18;
    const bottomReserve = variant === "moba" ? 108 : 64;
    const maxTargets = variant === "moba" ? 7 : mode === "battery" ? 3 : 6;

    const spawn = (now: number) => {
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      const pad = edgeProtect ? 28 : 12;
      targets.push({
        id: nextId++,
        x: pad + Math.random() * (w - pad * 2),
        y: pad + 48 + Math.random() * Math.max(80, h - pad * 2 - bottomReserve),
        r: variant === "moba" ? 14 + Math.random() * 10 : 28 + Math.random() * 16,
        born: now,
        life,
      });
    };

    const hitAt = (x: number, y: number, now: number) => {
      const w = canvas.clientWidth;
      if (edgeProtect && (x < 18 || x > w - 18)) return;
      let best = -1;
      let bestD = 1e9;
      for (let i = 0; i < targets.length; i += 1) {
        const t = targets[i];
        if (!t) continue;
        const d = Math.hypot(t.x - x, t.y - y);
        if (d <= t.r + hitPad && d < bestD) {
          bestD = d;
          best = i;
        }
      }
      if (best < 0) {
        stats.combo = 0;
        stats.misses += 1;
        onStatsRef.current({ ...stats });
        return;
      }
      const t = targets[best];
      if (!t) return;
      stats.hits += 1;
      stats.combo += 1;
      stats.latency = Math.round(now - t.born);
      stats.score += 10 + stats.combo * 2;
      for (let i = 0; i < particleN; i += 1) {
        const a = (Math.PI * 2 * i) / particleN;
        particles.push({
          x: t.x,
          y: t.y,
          vx: Math.cos(a) * 2.4,
          vy: Math.sin(a) * 2.4,
          life: 1,
        });
      }
      targets.splice(best, 1);
      onStatsRef.current({ ...stats });
    };

    const onPointer = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      hitAt(e.clientX - rect.left, e.clientY - rect.top, performance.now());
    };
    canvas.addEventListener("pointerdown", onPointer);

    const loop = (now: number) => {
      if (!running) return;
      const dt = now - last;
      last = now;
      acc += dt;
      if (acc < frameMs) {
        raf = requestAnimationFrame(loop);
        return;
      }
      const step = Math.min(acc, 48);
      acc = 0;
      frames += 1;
      if (now - fpsStamp >= 400) {
        stats.fps = Math.round((frames * 1000) / (now - fpsStamp));
        frames = 0;
        fpsStamp = now;
        onStatsRef.current({ ...stats });
      }

      spawnAcc += step * spawnRate;
      if (spawnAcc > 700 && targets.length < maxTargets) {
        spawn(now);
        spawnAcc = 0;
      }
      for (let i = targets.length - 1; i >= 0; i -= 1) {
        const t = targets[i];
        if (!t) continue;
        if (now - t.born > t.life) {
          targets.splice(i, 1);
          stats.combo = 0;
          stats.misses += 1;
        }
      }
      for (let i = particles.length - 1; i >= 0; i -= 1) {
        const p = particles[i];
        if (!p) continue;
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.045;
        if (p.life <= 0) particles.splice(i, 1);
      }

      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      ctx.fillStyle = "#0b0c0e";
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = "rgba(236,238,240,0.04)";
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 32) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }

      for (const t of targets) {
        const age = (now - t.born) / t.life;
        const rr = t.r * (1.15 - age * 0.35);
        ctx.beginPath();
        ctx.arc(t.x, t.y, rr, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(138,160,173,${0.95 - age * 0.5})`;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(t.x, t.y, Math.max(4, rr * (1 - age)), 0, Math.PI * 2);
        ctx.fillStyle = `rgba(138,160,173,${0.18 - age * 0.1})`;
        ctx.fill();
      }
      for (const p of particles) {
        ctx.fillStyle = `rgba(236,238,240,${p.life})`;
        ctx.fillRect(p.x, p.y, 2, 2);
      }

      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      canvas.removeEventListener("pointerdown", onPointer);
      ro.disconnect();
    };
  }, [mode, capFps, touchBoost, edgeProtect, canvasRef, variant]);

  return <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />;
}
